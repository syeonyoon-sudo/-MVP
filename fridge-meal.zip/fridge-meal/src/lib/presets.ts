import type { Settings, StorageType } from '../types'

export const TOOLS = ['칼·도마', '프라이팬', '냄비', '전자레인지', '에어프라이어', '오븐', '전기밥솥'] as const

export const SEASONINGS = [
  '소금', '설탕', '간장', '식용유', '참기름', '후추', '다진마늘', '고추장', '고춧가루',
  '된장', '굴소스', '케첩', '마요네즈', '버터', '참깨', '식초', '맛술',
]

export const TASTES = ['짭짤한', '매콤한', '달콤한', '담백한', '고소한', '새콤한', '감칠맛']

export const FOOD_TYPES = ['한식', '양식', '중식', '일식', '분식', '샐러드', '볶음밥·덮밥', '찌개·국', '면 요리', '고기 요리']

export const SPICY_LABELS = ['안 매운 맛', '약간 매운 맛', '보통 매운 맛', '아주 매운 맛']
export const SKILL_LABELS = { 1: '초보', 2: '보통', 3: '숙련' } as const
export const SKILL_DESC = {
  1: '씻기, 간단히 썰기, 전자레인지, 간단한 볶기·끓이기',
  2: '여러 재료 손질, 양념 배합, 굽기·볶기·조림',
  3: '복잡한 손질, 다단계 조리, 정교한 불·시간 조절',
} as const

export const STORAGE_LABEL: Record<StorageType, string> = { fridge: '냉장', freezer: '냉동', room: '실온' }

export const UNITS = ['개', 'g', 'kg', 'ml', 'L', '팩', '봉', '모', '대', '줄기', '캔', '장', '공기', '포기']

export interface QuickItem {
  name: string
  unit: string
  qty: number
  storage: StorageType
  days: number // 구매일 기준 일반적인 소비기한 추정치 (사용자가 수정 가능)
}

export const QUICK_ITEMS: QuickItem[] = [
  { name: '계란', unit: '개', qty: 10, storage: 'fridge', days: 21 },
  { name: '두부', unit: '모', qty: 1, storage: 'fridge', days: 5 },
  { name: '대파', unit: '대', qty: 1, storage: 'fridge', days: 7 },
  { name: '양파', unit: '개', qty: 2, storage: 'room', days: 21 },
  { name: '김치', unit: 'g', qty: 500, storage: 'fridge', days: 30 },
  { name: '돼지고기', unit: 'g', qty: 300, storage: 'fridge', days: 3 },
  { name: '닭가슴살', unit: 'g', qty: 200, storage: 'fridge', days: 2 },
  { name: '애호박', unit: '개', qty: 1, storage: 'fridge', days: 5 },
  { name: '감자', unit: '개', qty: 3, storage: 'room', days: 21 },
  { name: '우유', unit: 'ml', qty: 900, storage: 'fridge', days: 7 },
  { name: '햄', unit: 'g', qty: 200, storage: 'fridge', days: 14 },
  { name: '참치캔', unit: '캔', qty: 2, storage: 'room', days: 365 },
  { name: '콩나물', unit: 'g', qty: 300, storage: 'fridge', days: 3 },
  { name: '햇반', unit: '개', qty: 3, storage: 'room', days: 180 },
  { name: '버섯', unit: '팩', qty: 1, storage: 'fridge', days: 5 },
  { name: '양배추', unit: '개', qty: 1, storage: 'fridge', days: 14 },
]

export const DEFAULT_SETTINGS: Settings = {
  skill: 1,
  likedFoods: [],
  dislikedFoods: [],
  tastes: [],
  spicy: 1,
  maxTime: 30,
  canBuy: false,
  tools: ['칼·도마', '프라이팬', '냄비', '전자레인지'],
  allergies: [],
  pantry: ['소금', '설탕', '간장', '식용유', '참기름', '후추', '다진마늘', '고추장', '고춧가루'],
  forceDemo: false,
  onboarded: false,
}

/** 알레르기 입력어 → 함께 막아야 하는 재료 묶음 (안전을 위해 넓게 잡음) */
export const ALLERGEN_GROUPS: Record<string, string[]> = {
  달걀: ['계란', '달걀', '유정란', '마요네즈'],
  우유: ['우유', '치즈', '버터', '크림', '생크림', '모짜렐라'],
  밀: ['밀가루', '부침가루', '튀김가루', '파스타', '스파게티', '라면', '카레', '간장', '고추장', '밀떡', '빵'],
  대두: ['두부', '간장', '된장', '고추장', '콩나물'],
  땅콩: ['땅콩'],
  갑각류: ['새우', '게', '랍스터'],
  생선: ['참치', '어묵', '연어', '고등어', '멸치'],
  돼지고기: ['돼지고기', '삼겹살', '목살', '앞다리살', '햄', '베이컨', '소시지', '스팸'],
  소고기: ['소고기', '쇠고기', '불고기', '차돌박이'],
  닭고기: ['닭고기', '닭가슴살', '닭다리살', '닭'],
  토마토: ['토마토', '케첩', '토마토소스', '파스타소스'],
}
const ALLERGEN_SYNONYM: Record<string, string> = { 계란: '달걀', 밀가루: '밀', 콩: '대두', 새우: '갑각류', 게: '갑각류', 해산물: '갑각류', 유제품: '우유', 돼지: '돼지고기', 소: '소고기', 닭: '닭고기', 어류: '생선' }

export function expandAllergy(term: string): string[] {
  const t = term.trim()
  if (!t) return []
  const key = ALLERGEN_SYNONYM[t] ?? t
  const extra = key === '생선' || key === '갑각류' ? [] : []
  return Array.from(new Set([t, ...(ALLERGEN_GROUPS[key] ?? []), ...extra]))
}

/** 오늘 다 못 쓰는 재료 중 냉동 보관으로 연장 가능한 것 */
const FREEZABLE = ['고기', '돼지', '소고기', '닭', '대파', '파', '밥', '햇반', '빵', '버섯', '어묵', '떡', '햄', '베이컨', '소시지', '애호박', '두부', '김치', '양배추']
export function isFreezable(name: string) {
  return FREEZABLE.some((k) => name.includes(k))
}

export const SAMPLE_OFFSETS: { name: string; quantity: number; unit: string; storage: StorageType; offset: number }[] = [
  { name: '두부', quantity: 1, unit: '모', storage: 'fridge', offset: 0 },
  { name: '애호박', quantity: 1, unit: '개', storage: 'fridge', offset: 2 },
  { name: '계란', quantity: 6, unit: '개', storage: 'fridge', offset: 9 },
  { name: '대파', quantity: 1, unit: '대', storage: 'fridge', offset: 3 },
  { name: '양파', quantity: 2, unit: '개', storage: 'room', offset: 14 },
  { name: '김치', quantity: 400, unit: 'g', storage: 'fridge', offset: 20 },
  { name: '햇반', quantity: 2, unit: '개', storage: 'room', offset: 120 },
  { name: '돼지고기', quantity: 200, unit: 'g', storage: 'fridge', offset: 1 },
  { name: '우유', quantity: 500, unit: 'ml', storage: 'fridge', offset: -1 },
]
