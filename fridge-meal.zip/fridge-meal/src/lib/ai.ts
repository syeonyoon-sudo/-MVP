import type { Ingredient, Recipe, RecResult, Settings } from '../types'
import { analyze, buildContext, explainTodayUnused, priorityGroups, recommendDemo, ruleCandidates, toMenuRec } from './recommend'
import { RECIPES } from './recipes'
import { SKILL_LABELS, SPICY_LABELS, STORAGE_LABEL, TOOLS } from './presets'

export interface AiStatus {
  available: boolean
  model?: string
}

/** 서버(Vercel 함수)에 API 키가 설정되어 있는지 확인. 실패하면 데모 모드 */
export async function fetchAiStatus(): Promise<AiStatus> {
  try {
    const ctrl = new AbortController()
    const t = setTimeout(() => ctrl.abort(), 5000)
    const res = await fetch('/api/status', { signal: ctrl.signal })
    clearTimeout(t)
    if (!res.ok) return { available: false }
    const data = await res.json()
    return { available: !!data.aiAvailable, model: data.model }
  } catch {
    return { available: false }
  }
}

interface AiMenu {
  name: string
  category?: string
  difficulty: number
  time: number
  tools: string[]
  spicy?: number
  tastes?: string[]
  reason: string
  ingredients: { name: string; amount: string; kind: 'main' | 'seasoning'; optional?: boolean }[]
  steps: { text: string; minutes?: number }[]
  tips?: string[]
}

function toRecipe(m: AiMenu, i: number): Recipe | null {
  if (!m || typeof m.name !== 'string' || !Array.isArray(m.ingredients) || !Array.isArray(m.steps) || m.steps.length < 2) return null
  const difficulty = Math.min(3, Math.max(1, Math.round(Number(m.difficulty) || 3))) as 1 | 2 | 3
  const cats = ['한식', '양식', '중식', '일식', '분식', '샐러드']
  return {
    id: `ai-${Date.now().toString(36)}-${i}`,
    name: m.name.slice(0, 40),
    category: (cats.includes(m.category ?? '') ? m.category : '한식') as Recipe['category'],
    difficulty,
    time: Math.max(1, Math.round(Number(m.time) || 999)),
    tools: (m.tools ?? []).filter((t) => typeof t === 'string'),
    spicy: Math.min(3, Math.max(0, Math.round(Number(m.spicy) || 0))) as 0 | 1 | 2 | 3,
    tastes: (m.tastes ?? []).slice(0, 4),
    ingredients: m.ingredients
      .filter((x) => x && typeof x.name === 'string')
      .map((x) => ({ name: x.name, amount: String(x.amount ?? ''), kind: x.kind === 'seasoning' ? 'seasoning' : 'main', optional: !!x.optional })),
    steps: m.steps.filter((s) => s && typeof s.text === 'string').map((s) => ({ text: s.text, minutes: Number(s.minutes) || undefined })),
    tips: (m.tips ?? []).filter((t) => typeof t === 'string').slice(0, 5),
  }
}

/**
 * 실제 AI 추천
 * - 우선 소비 재료·필수 조건은 규칙 로직으로 계산해 AI에게 전달
 * - AI가 돌려준 메뉴는 브라우저에서 다시 한 번 규칙으로 검증 (시간·도구·난이도·알레르기·구매 개수)
 * - 검증을 통과한 메뉴가 하나도 없으면 데모(규칙 기반) 추천으로 대체
 */
export async function recommendAI(inventory: Ingredient[], settings: Settings, exclude: string[], prevNames: string[]): Promise<RecResult> {
  const ctx = buildContext(inventory, settings)
  const groups = priorityGroups(ctx)
  const candidates = ruleCandidates(inventory, settings)

  const payload = {
    today: ctx.today,
    inventory: ctx.valid.map((c) => ({ name: c.item.name, quantity: c.item.quantity, unit: c.item.unit, daysLeft: c.days, storage: STORAGE_LABEL[c.item.storage] })),
    expired: ctx.expired.map((c) => c.item.name),
    mustUseToday: groups.today.map((c) => c.item.name),
    urgent: groups.urgent.map((c) => ({ name: c.item.name, daysLeft: c.days })),
    pantry: settings.pantry,
    user: {
      skill: SKILL_LABELS[settings.skill],
      skillLevel: settings.skill,
      maxTime: settings.maxTime,
      canBuy: settings.canBuy,
      buyLimit: ctx.buyLimit,
      tools: settings.tools,
      allTools: TOOLS,
      allergies: settings.allergies,
      liked: settings.likedFoods,
      disliked: settings.dislikedFoods,
      tastes: settings.tastes,
      spicy: SPICY_LABELS[settings.spicy],
    },
    candidates: candidates.map((a) => ({ name: a.recipe.name, time: a.recipe.time, difficulty: a.recipe.difficulty, toBuy: a.toBuy.map((t) => t.name) })),
    avoid: prevNames,
  }

  let fallbackReason = ''
  try {
    const ctrl = new AbortController()
    const t = setTimeout(() => ctrl.abort(), 60000)
    const res = await fetch('/api/recommend', { method: 'POST', headers: { 'Content-Type': 'application/json' }, body: JSON.stringify(payload), signal: ctrl.signal })
    clearTimeout(t)
    const data = await res.json().catch(() => ({}))
    if (!res.ok) throw new Error(data?.error || `서버 오류 (${res.status})`)

    const reasons = new Map<string, string>()
    const recipes: Recipe[] = []
    ;((Array.isArray(data.menus) ? data.menus : []) as AiMenu[]).forEach((m, i) => {
      const r = toRecipe(m, i)
      if (r) {
        recipes.push(r)
        reasons.set(r.id, typeof m.reason === 'string' ? m.reason : '')
      }
    })
    const analyses = recipes.map((r) => analyze(r, ctx))
    const valid = analyses.filter((a) => !a.blocked).slice(0, 3)
    if (valid.length) {
      const all = [...RECIPES.map((r) => analyze(r, ctx)), ...analyses]
      const rejected = analyses.length - valid.length
      return {
        id: `r${Date.now()}`,
        createdAt: Date.now(),
        mode: 'ai',
        fallbackReason: rejected ? `AI가 제안한 메뉴 중 ${rejected}개는 필수 조건(시간·도구·난이도·알레르기·구매 개수)을 지키지 않아 제외했어요.` : undefined,
        menus: valid.map((a) => toMenuRec(a, 'ai', reasons.get(a.recipe.id) || '')),
        todayUnused: explainTodayUnused(all, valid, ctx).map((t) => {
          const aiNote = (Array.isArray(data.todayUnused) ? data.todayUnused : []).find((x: any) => x && typeof x.name === 'string' && t.name.includes(x.name))
          const ruleAlt = all.find((a) => !a.blocked && !valid.includes(a) && a.usedInvNames.includes(t.name))
          if (aiNote?.reason) return { name: t.name, reason: String(aiNote.reason), alternative: String(aiNote.alternative || t.alternative) }
          if (ruleAlt) return { name: t.name, reason: 'AI가 고른 메뉴에는 이 재료가 들어가지 않았어요.', alternative: `조건에 맞는 '${ruleAlt.recipe.name}' 메뉴로도 사용할 수 있어요. ‘다른 메뉴 보기’를 눌러 보세요.` }
          return t
        }),
        expiredExcluded: ctx.expired.map((c) => c.item.name),
        settingsSnapshot: { skill: settings.skill, maxTime: settings.maxTime, canBuy: settings.canBuy },
        shownIds: valid.map((a) => a.recipe.id),
      }
    }
    fallbackReason = 'AI가 제안한 메뉴가 필수 조건 검증을 통과하지 못해 규칙 기반(데모) 추천으로 대신 보여드려요.'
  } catch (e) {
    const msg = e instanceof Error ? (e.name === 'AbortError' ? '응답 시간이 초과됐어요' : e.message) : '알 수 없는 오류'
    fallbackReason = `AI 추천에 실패해(${msg}) 규칙 기반(데모) 추천으로 대신 보여드려요.`
  }
  const demo = recommendDemo(inventory, settings, exclude)
  return { ...demo, fallbackReason }
}
