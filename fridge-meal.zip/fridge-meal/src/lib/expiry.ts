import type { Ingredient } from '../types'

/** 오늘 날짜(사용자 기기 시간 기준)를 YYYY-MM-DD 로 반환 */
export function todayStr(d = new Date()): string {
  const y = d.getFullYear()
  const m = String(d.getMonth() + 1).padStart(2, '0')
  const day = String(d.getDate()).padStart(2, '0')
  return `${y}-${m}-${day}`
}

export function addDays(base: string, days: number): string {
  const [y, m, d] = base.split('-').map(Number)
  const dt = new Date(y, m - 1, d + days)
  return todayStr(dt)
}

/** 소비기한까지 남은 일수. 0 = 오늘까지, 음수 = 지남 */
export function daysLeft(expiry: string, today = todayStr()): number {
  const [y1, m1, d1] = expiry.split('-').map(Number)
  const [y2, m2, d2] = today.split('-').map(Number)
  return Math.round((Date.UTC(y1, m1 - 1, d1) - Date.UTC(y2, m2 - 1, d2)) / 86400000)
}

export type ExpiryStatus = 'expired' | 'today' | 'urgent' | 'soon' | 'fresh'

/**
 * 규칙 기반 소비기한 상태
 * - expired: 소비기한 지남 (추천에서 제외)
 * - today:   오늘까지 (반드시 사용 대상)
 * - urgent:  1~3일 남음 (우선 고려)
 * - soon:    4~7일 남음
 * - fresh:   8일 이상
 */
export function statusOf(days: number): ExpiryStatus {
  if (days < 0) return 'expired'
  if (days === 0) return 'today'
  if (days <= 3) return 'urgent'
  if (days <= 7) return 'soon'
  return 'fresh'
}

export const STATUS_META: Record<ExpiryStatus, { label: string; badge: string; dot: string }> = {
  expired: { label: '기한 지남', badge: 'bg-stone-200 text-stone-600', dot: 'bg-stone-400' },
  today: { label: '오늘까지', badge: 'bg-red-50 text-red-700 ring-1 ring-red-200', dot: 'bg-red-500' },
  urgent: { label: '임박', badge: 'bg-amber-50 text-amber-800 ring-1 ring-amber-200', dot: 'bg-amber-500' },
  soon: { label: '일주일 이내', badge: 'bg-sage-50 text-sage-700 ring-1 ring-sage-200', dot: 'bg-sage-400' },
  fresh: { label: '여유', badge: 'bg-white text-stone-500 ring-1 ring-stone-200', dot: 'bg-sage-300' },
}

export function dLabel(days: number): string {
  if (days < 0) return `${-days}일 지남`
  if (days === 0) return 'D-day'
  return `D-${days}`
}

export interface Classified {
  item: Ingredient
  days: number
  status: ExpiryStatus
}

export function classify(items: Ingredient[], today = todayStr()): Classified[] {
  return items
    .map((item) => {
      const days = daysLeft(item.expiry, today)
      return { item, days, status: statusOf(days) }
    })
    .sort((a, b) => a.days - b.days || a.item.name.localeCompare(b.item.name, 'ko'))
}

export function formatDate(s: string): string {
  const [, m, d] = s.split('-').map(Number)
  return `${m}월 ${d}일`
}
