import type { RecipeIngredient } from '../types'
import { expandAllergy } from './presets'

export const norm = (s: string) => s.replace(/\s+/g, '').toLowerCase()

export function keysOf(ing: Pick<RecipeIngredient, 'name' | 'aliases'>): string[] {
  return [ing.name, ...(ing.aliases ?? [])]
}

/** 보유 재료명이 레시피 재료(별칭 포함)와 같은 재료인지 */
export function nameMatches(ownedName: string, keys: string[]): boolean {
  const n = norm(ownedName)
  if (!n) return false
  return keys.some((k) => {
    const kk = norm(k)
    return n === kk || (kk.length >= 2 && n.includes(kk))
  })
}

/** 알레르기·금기 재료가 포함되어 있는지 (안전을 위해 양방향 포함 검사) */
export function hitsAllergy(ingredients: Pick<RecipeIngredient, 'name' | 'aliases'>[], allergies: string[]): string | null {
  for (const a of allergies) {
    const words = expandAllergy(a).map(norm).filter(Boolean)
    for (const ing of ingredients) {
      for (const k of keysOf(ing).map(norm)) {
        if (words.some((w) => k.includes(w) || (k.length >= 2 && w.includes(k)))) return a
      }
    }
  }
  return null
}

/** 비선호 음식과 겹치는지 (취향 감점용) */
export function hitsWord(text: string, words: string[]): string | null {
  const t = norm(text)
  for (const w of words) {
    const ww = norm(w)
    if (ww && t.includes(ww)) return w
  }
  return null
}
