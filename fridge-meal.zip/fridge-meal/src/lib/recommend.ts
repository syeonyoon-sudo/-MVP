import type { Ingredient, MenuRec, PriorityItem, Recipe, RecResult, Settings, TodayUnused } from '../types'
import { classify, type Classified, todayStr } from './expiry'
import { hitsAllergy, hitsWord, keysOf, nameMatches } from './match'
import { isFreezable, SKILL_LABELS } from './presets'
import { RECIPES } from './recipes'

export type BlockReason = 'allergy' | 'tools' | 'time' | 'difficulty' | 'nomain' | 'buy'

export interface Analysis {
  recipe: Recipe
  owned: string[]
  optionalOwned: string[]
  ownedSeasonings: string[]
  toBuy: { name: string; kind: 'main' | 'seasoning' }[]
  priorityUsed: PriorityItem[]
  usedInvNames: string[]
  expiredSkipped: string[]
  blocked: BlockReason | null
  blockDetail: string
  score: number
  prefHits: string[]
  dislikeHit: string | null
}

export interface Context {
  today: string
  valid: Classified[] // 기한이 지나지 않은 보유 재료
  expired: Classified[]
  settings: Settings
  buyLimit: number
}

export function buildContext(inventory: Ingredient[], settings: Settings): Context {
  const today = todayStr()
  const all = classify(inventory, today)
  return {
    today,
    valid: all.filter((c) => c.status !== 'expired'),
    expired: all.filter((c) => c.status === 'expired'),
    settings,
    buyLimit: settings.canBuy ? 3 : 0,
  }
}

/** 오늘까지 / 1~3일 남은 재료 (날짜 규칙으로만 계산) */
export function priorityGroups(ctx: Context) {
  return {
    today: ctx.valid.filter((c) => c.status === 'today'),
    urgent: ctx.valid.filter((c) => c.status === 'urgent'),
    soon: ctx.valid.filter((c) => c.status === 'soon'),
  }
}

function findOwned(ctx: Context, keys: string[]): Classified | undefined {
  // 소비기한이 가장 임박한 것부터 사용
  return ctx.valid.find((c) => nameMatches(c.item.name, keys))
}

function pantryHas(ctx: Context, keys: string[]): boolean {
  return ctx.settings.pantry.some((p) => nameMatches(p, keys) || keys.some((k) => nameMatches(k, [p])))
}

export function analyze(recipe: Recipe, ctx: Context): Analysis {
  const { settings } = ctx
  const owned: string[] = []
  const optionalOwned: string[] = []
  const ownedSeasonings: string[] = []
  const toBuy: Analysis['toBuy'] = []
  const priority = new Map<string, PriorityItem>()
  const usedInv: string[] = []
  const expiredSkipped: string[] = []

  for (const ing of recipe.ingredients) {
    const keys = keysOf(ing)
    const hit = findOwned(ctx, keys)
    if (ing.kind === 'seasoning') {
      if (hit || pantryHas(ctx, keys)) ownedSeasonings.push(ing.name)
      else if (!ing.optional) toBuy.push({ name: ing.name, kind: 'seasoning' })
    } else if (hit) {
      ;(ing.optional ? optionalOwned : owned).push(ing.name)
      usedInv.push(hit.item.name)
    } else {
      const exp = ctx.expired.find((c) => nameMatches(c.item.name, keys))
      if (exp) expiredSkipped.push(exp.item.name)
      if (!ing.optional) toBuy.push({ name: ing.name, kind: 'main' })
    }
    if (hit && hit.days <= 3) priority.set(hit.item.id, { name: hit.item.name, daysLeft: hit.days })
  }

  // ── 필수 조건 검사 (순서대로) ──
  let blocked: BlockReason | null = null
  let blockDetail = ''
  const allergy = hitsAllergy(recipe.ingredients, settings.allergies)
  const missingTools = recipe.tools.filter((t) => !settings.tools.includes(t))
  if (allergy) {
    blocked = 'allergy'
    blockDetail = `알레르기·금기 재료(${allergy})가 들어가요`
  } else if (missingTools.length) {
    blocked = 'tools'
    blockDetail = `${missingTools.join(', ')}${josa(missingTools[missingTools.length - 1], '이', '가')} 필요해요`
  } else if (recipe.time > settings.maxTime) {
    blocked = 'time'
    blockDetail = `조리시간이 ${recipe.time}분이라 설정한 ${settings.maxTime}분을 넘어요`
  } else if (recipe.difficulty > settings.skill) {
    blocked = 'difficulty'
    blockDetail = `난이도가 '${SKILL_LABELS[recipe.difficulty]}'${josa(SKILL_LABELS[recipe.difficulty], '이라', '라')} 현재 실력(${SKILL_LABELS[settings.skill]})보다 어려워요`
  } else if (owned.length === 0) {
    blocked = 'nomain'
    blockDetail = '보유한 주재료가 하나도 없어요'
  } else if (toBuy.length > ctx.buyLimit) {
    blocked = 'buy'
    blockDetail = ctx.buyLimit === 0 ? `추가 구매 재료가 ${toBuy.length}개 필요해요(현재 '구매 불가' 설정)` : `추가 구매 재료가 ${toBuy.length}개라 최대 3개를 넘어요`
  }

  // ── 우선순위 점수 ──
  const pri = [...priority.values()]
  let score = 0
  score += pri.filter((p) => p.daysLeft === 0).length * 40
  score += pri.filter((p) => p.daysLeft >= 1 && p.daysLeft <= 3).length * 18
  score += ctx.valid.filter((c) => c.status === 'soon' && usedInv.includes(c.item.name)).length * 4
  const mains = recipe.ingredients.filter((i) => i.kind === 'main' && !i.optional).length || 1
  score += (owned.length / mains) * 12 + optionalOwned.length * 2
  score -= toBuy.length * 9

  const prefHits: string[] = []
  const likeText = `${recipe.name} ${recipe.category} ${recipe.ingredients.map((i) => i.name).join(' ')}`
  const like = hitsWord(likeText, settings.likedFoods) ?? matchFoodType(recipe, settings.likedFoods)
  if (like) {
    score += 12
    prefHits.push(like)
  }
  for (const t of recipe.tastes) {
    if (settings.tastes.includes(t)) {
      score += 5
      prefHits.push(t)
    }
  }
  score -= Math.max(0, recipe.spicy - settings.spicy) * 8
  const dislikeHit = hitsWord(likeText, settings.dislikedFoods) ?? matchFoodType(recipe, settings.dislikedFoods)
  if (dislikeHit) score -= 30

  return { recipe, owned, optionalOwned, ownedSeasonings, toBuy, priorityUsed: pri.sort((a, b) => a.daysLeft - b.daysLeft), usedInvNames: usedInv, expiredSkipped, blocked, blockDetail, score, prefHits, dislikeHit }
}

/** '볶음밥·덮밥', '찌개·국', '면 요리', '고기 요리' 같은 묶음 취향 매칭 */
function matchFoodType(r: Recipe, list: string[]): string | null {
  for (const w of list) {
    if (w === r.category) return w
    if (w === '볶음밥·덮밥' && /볶음밥|덮밥|계란밥|오야코동|카레라이스/.test(r.name)) return w
    if (w === '찌개·국' && /찌개|국|탕/.test(r.name)) return w
    if (w === '면 요리' && /파스타|라면|면/.test(r.name)) return w
    if (w === '고기 요리' && r.ingredients.some((i) => !i.optional && /고기|닭|소고기|돼지/.test(i.name))) return w
  }
  return null
}

export function writeReason(a: Analysis, ctx: Context): string {
  const parts: string[] = []
  const today = a.priorityUsed.filter((p) => p.daysLeft === 0).map((p) => p.name)
  const urgent = a.priorityUsed.filter((p) => p.daysLeft > 0).map((p) => p.name)
  if (today.length) parts.push(`오늘까지 먹어야 하는 ${joinKo(today)}${eulReul(today)} 바로 쓸 수 있어요.`)
  if (urgent.length) parts.push(`${today.length ? '또 ' : ''}소비기한이 1~3일 남은 ${joinKo(urgent)}도 함께 소진해요.`)
  if (!today.length && !urgent.length) parts.push(`지금 냉장고에 있는 ${joinKo(a.owned.slice(0, 3))}${eulReul(a.owned.slice(0, 3))} 중심으로 만들 수 있어요.`)
  parts.push(a.toBuy.length === 0 ? `추가 구매 없이 ${a.recipe.time}분 안에 완성돼요.` : `${a.toBuy.length}가지만 사면 ${a.recipe.time}분 안에 완성돼요.`)
  if (a.prefHits.length) parts.push(`좋아하는 '${a.prefHits.slice(0, 2).join("', '")}' 취향과도 잘 맞아요.`)
  if (a.dislikeHit) parts.push(`다만 비선호로 설정한 '${a.dislikeHit}'${josa(a.dislikeHit, '이', '가')} 포함돼 있어요.`)
  if (ctx.settings.skill === 1 && a.recipe.difficulty === 1) parts.push('초보도 따라 하기 쉬운 단계로 구성돼 있어요.')
  return parts.join(' ')
}

/** 받침 유무에 따라 조사 선택 (예: josa('두부','을','를') → '를') */
export function josa(word: string, withBatchim: string, without: string) {
  const code = word.charCodeAt(word.length - 1) - 0xac00
  if (code < 0 || code > 11171) return `${withBatchim}(${without})`
  return code % 28 === 0 ? without : withBatchim
}
function joinKo(list: string[]) {
  if (list.length <= 1) return list[0] ?? ''
  const head = list.slice(0, -1).join(', ')
  return `${head}${josa(list[list.length - 2], '과', '와')} ${list[list.length - 1]}`
}
function eulReul(list: string[]) {
  return josa(list[list.length - 1] ?? '', '을', '를')
}

export function toMenuRec(a: Analysis, source: 'demo' | 'ai', reason: string): MenuRec {
  return {
    recipe: a.recipe,
    source,
    reason,
    priorityUsed: a.priorityUsed,
    owned: a.owned,
    ownedSeasonings: a.ownedSeasonings,
    toBuy: a.toBuy,
    optionalOwned: a.optionalOwned,
  }
}

/**
 * 후보 중 최종 메뉴 고르기
 * 1) 오늘까지인 재료를 쓰는 메뉴를 재료별로 먼저 확보
 * 2) 남은 자리는 점수순(우선 소비 + 보유 비율 + 취향)으로 채움
 * 조건을 통과한 메뉴가 3개 미만이면 그만큼만 반환
 */
export function pickMenus(eligible: Analysis[], ctx: Context, max = 3): Analysis[] {
  const sorted = [...eligible].sort((a, b) => b.score - a.score)
  const picked: Analysis[] = []
  const todayItems = priorityGroups(ctx).today
  for (const t of todayItems) {
    if (picked.length >= max) break
    if (picked.some((p) => p.usedInvNames.includes(t.item.name))) continue
    const best = sorted.find((a) => !picked.includes(a) && a.usedInvNames.includes(t.item.name))
    if (best) picked.push(best)
  }
  for (const a of sorted) {
    if (picked.length >= max) break
    if (!picked.includes(a)) picked.push(a)
  }
  return picked.sort((a, b) => b.score - a.score)
}

const ALT: Record<BlockReason, (ctx: Context) => string> = {
  allergy: () => '알레르기·금기 재료가 함께 들어가는 메뉴뿐이라 추천하지 않았어요.',
  tools: () => '해당 조리도구가 있다면 설정에서 추가해 주세요.',
  time: (ctx) => `조리 가능 시간을 ${ctx.settings.maxTime < 60 ? (ctx.settings.maxTime === 10 ? 20 : ctx.settings.maxTime === 20 ? 30 : 60) : 60}분으로 늘리면 추천받을 수 있어요.`,
  difficulty: () => '요리 실력을 한 단계 올리면 추천받을 수 있어요.',
  nomain: () => '',
  buy: (ctx) => (ctx.settings.canBuy ? '' : "추가 구매 의향을 '가능'으로 바꾸면 추천받을 수 있어요."),
}

/** 오늘까지인 재료를 쓰지 못한 경우: 구체적 사유 + 대안 */
export function explainTodayUnused(all: Analysis[], picked: Analysis[], ctx: Context, exclude: string[] = []): TodayUnused[] {
  const out: TodayUnused[] = []
  for (const t of priorityGroups(ctx).today) {
    if (picked.some((p) => p.usedInvNames.includes(t.item.name))) continue
    const users = all.filter((a) => a.usedInvNames.includes(t.item.name))
    const storageTip = isFreezable(t.item.name) && t.item.storage !== 'freezer' ? '오늘 조리가 어렵다면 소분해서 오늘 안에 냉동 보관하세요(해동 후에는 바로 조리).' : ''
    const safety = '상태(냄새·색·끈적임)가 이상하면 기한과 관계없이 섭취하지 마세요.'
    if (!users.length) {
      out.push({ name: t.item.name, reason: '현재 메뉴 데이터에 이 재료를 주재료로 쓰는 메뉴가 없어요.', alternative: [storageTip || '간단히 데치거나 구워 반찬으로 곁들이는 방법을 고려해 보세요.', safety].join(' ') })
      continue
    }
    const blockedUsers = users.filter((u) => u.blocked)
    if (blockedUsers.length === users.length) {
      const first = blockedUsers[0]
      const alt = ALT[first.blocked!](ctx)
      out.push({ name: t.item.name, reason: `이 재료를 쓰는 '${first.recipe.name}'${josa(first.recipe.name.replace(/\)$/, ''), '은', '는')} ${first.blockDetail}.`, alternative: [alt, storageTip, safety].filter(Boolean).join(' ') })
    } else if (users.filter((u) => !u.blocked).every((u) => exclude.includes(u.recipe.id))) {
      const names = users.filter((u) => !u.blocked).map((u) => `'${u.recipe.name}'`).slice(0, 2).join(', ')
      out.push({ name: t.item.name, reason: `이 재료를 쓸 수 있는 메뉴(${names})는 이전 추천에서 이미 보여드렸어요.`, alternative: ['‘다시 추천’을 누르면 해당 메뉴를 다시 볼 수 있어요.', storageTip, safety].filter(Boolean).join(' ') })
    } else {
      out.push({ name: t.item.name, reason: '오늘까지인 재료가 많아 추천 3개 안에 모두 담지 못했어요.', alternative: ['‘다른 메뉴 보기’로 이 재료를 쓰는 메뉴를 확인해 보세요.', storageTip, safety].filter(Boolean).join(' ') })
    }
  }
  return out
}

export function emptyReasonOf(all: Analysis[], ctx: Context): string {
  if (!ctx.valid.length) return ctx.expired.length ? '소비기한이 남은 식재료가 없어요. 기한이 지난 재료는 추천에 사용하지 않아요.' : '냉장고에 등록된 식재료가 없어요.'
  const counts = new Map<BlockReason, number>()
  all.forEach((a) => a.blocked && counts.set(a.blocked, (counts.get(a.blocked) ?? 0) + 1))
  const top = [...counts.entries()].filter(([k]) => k !== 'nomain').sort((a, b) => b[1] - a[1])[0]
  if (!top) return '보유한 재료로 만들 수 있는 메뉴를 찾지 못했어요. 식재료를 더 등록해 보세요.'
  const msg: Record<BlockReason, string> = {
    allergy: '알레르기·금기 재료 때문에 제외된 메뉴가 많아요.',
    tools: '사용 가능한 조리도구가 부족해 제외된 메뉴가 많아요. 설정에서 조리도구를 확인해 주세요.',
    time: '조리 가능 시간 안에 끝나는 메뉴가 없어요. 설정에서 시간을 늘려 보세요.',
    difficulty: '현재 요리 실력에 맞는 메뉴가 없어요.',
    nomain: '',
    buy: ctx.settings.canBuy ? '추가 구매 재료가 4개 이상 필요한 메뉴뿐이에요.' : "추가 구매 없이 만들 수 있는 메뉴가 없어요. 설정에서 추가 구매를 '가능'으로 바꾸면 최대 3개까지 사서 만드는 메뉴를 추천해요.",
  }
  return msg[top[0]]
}

/** 규칙 기반(데모) 추천 */
export function recommendDemo(inventory: Ingredient[], settings: Settings, exclude: string[] = []): RecResult {
  const ctx = buildContext(inventory, settings)
  const all = RECIPES.map((r) => analyze(r, ctx))
  let eligible = all.filter((a) => !a.blocked)
  const fresh = eligible.filter((a) => !exclude.includes(a.recipe.id))
  const rotated = fresh.length > 0 && exclude.length > 0
  if (fresh.length) eligible = fresh
  const picked = pickMenus(eligible, ctx)
  return {
    id: `r${Date.now()}`,
    createdAt: Date.now(),
    mode: 'demo',
    menus: picked.map((a) => toMenuRec(a, 'demo', writeReason(a, ctx))),
    todayUnused: explainTodayUnused(all, picked, ctx, rotated ? exclude : []),
    expiredExcluded: ctx.expired.map((c) => c.item.name),
    emptyReason: picked.length ? undefined : emptyReasonOf(all, ctx),
    settingsSnapshot: { skill: settings.skill, maxTime: settings.maxTime, canBuy: settings.canBuy },
    shownIds: rotated ? [...exclude, ...picked.map((p) => p.recipe.id)] : picked.map((p) => p.recipe.id),
  }
}

/** AI에게 참고용으로 넘길 후보 (규칙을 통과한 메뉴 상위 8개) */
export function ruleCandidates(inventory: Ingredient[], settings: Settings) {
  const ctx = buildContext(inventory, settings)
  return RECIPES.map((r) => analyze(r, ctx))
    .filter((a) => !a.blocked)
    .sort((a, b) => b.score - a.score)
    .slice(0, 8)
}
