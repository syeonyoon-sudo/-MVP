export type StorageType = 'fridge' | 'freezer' | 'room'

export interface Ingredient {
  id: string
  name: string
  quantity: number
  unit: string
  expiry: string // YYYY-MM-DD
  storage: StorageType
  createdAt: number
}

export type Skill = 1 | 2 | 3 // 1 초보, 2 보통, 3 숙련
export type MaxTime = 10 | 20 | 30 | 60

export interface Settings {
  skill: Skill
  likedFoods: string[]
  dislikedFoods: string[]
  tastes: string[]
  spicy: 0 | 1 | 2 | 3
  maxTime: MaxTime
  canBuy: boolean
  tools: string[]
  allergies: string[]
  pantry: string[] // 보유 양념
  forceDemo: boolean
  onboarded: boolean
}

export interface RecipeIngredient {
  name: string
  amount: string
  kind: 'main' | 'seasoning'
  aliases?: string[]
  optional?: boolean
}

export interface RecipeStep {
  text: string
  minutes?: number
}

export type Category = '한식' | '양식' | '중식' | '일식' | '분식' | '샐러드'

export interface Recipe {
  id: string
  name: string
  category: Category
  difficulty: Skill
  time: number
  tools: string[]
  spicy: 0 | 1 | 2 | 3
  tastes: string[]
  ingredients: RecipeIngredient[]
  steps: RecipeStep[]
  tips: string[]
}

export interface PriorityItem {
  name: string
  daysLeft: number
}

export interface MenuRec {
  recipe: Recipe
  source: 'demo' | 'ai'
  reason: string
  priorityUsed: PriorityItem[]
  owned: string[] // 레시피 재료명 (보유)
  ownedSeasonings: string[]
  toBuy: { name: string; kind: 'main' | 'seasoning' }[]
  optionalOwned: string[]
}

export interface TodayUnused {
  name: string
  reason: string
  alternative: string
}

export interface RecResult {
  id: string
  createdAt: number
  mode: 'demo' | 'ai'
  fallbackReason?: string
  menus: MenuRec[]
  todayUnused: TodayUnused[]
  expiredExcluded: string[]
  emptyReason?: string
  settingsSnapshot: { skill: Skill; maxTime: MaxTime; canBuy: boolean }
  shownIds: string[]
  inputKey?: string
}
