import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from 'react'
import type { Ingredient, RecResult, Settings } from './types'
import { DEFAULT_SETTINGS } from './lib/presets'
import { fetchAiStatus, type AiStatus } from './lib/ai'

/**
 * 데이터 저장: 브라우저 localStorage
 * - fh.inventory.v1 : 보유 식재료 (이름·수량·단위·소비기한·보관방식)
 * - fh.settings.v1  : 요리 실력·취향·조리 조건·조리도구·알레르기·보유 양념
 * - fh.lastResult.v1: 마지막 추천 결과 (새로고침해도 상세 조리법 확인 가능)
 */
const KEYS = { inventory: 'fh.inventory.v1', settings: 'fh.settings.v1', result: 'fh.lastResult.v1' }

function load<T>(key: string, fallback: T): T {
  try {
    const raw = localStorage.getItem(key)
    return raw ? (JSON.parse(raw) as T) : fallback
  } catch {
    return fallback
  }
}
function save(key: string, value: unknown) {
  try {
    localStorage.setItem(key, JSON.stringify(value))
  } catch {
    /* 저장 공간이 없거나 비공개 모드 */
  }
}

interface Store {
  inventory: Ingredient[]
  addIngredient: (i: Omit<Ingredient, 'id' | 'createdAt'>) => void
  addMany: (list: Omit<Ingredient, 'id' | 'createdAt'>[]) => void
  updateIngredient: (id: string, patch: Partial<Ingredient>) => void
  removeIngredient: (id: string) => void
  removeMany: (ids: string[]) => void
  settings: Settings
  setSettings: (s: Settings) => void
  result: RecResult | null
  setResult: (r: RecResult | null) => void
  ai: AiStatus & { checked: boolean }
  useAi: boolean
  toast: string | null
  showToast: (msg: string) => void
}

const Ctx = createContext<Store | null>(null)

const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36).slice(-4)

export function StoreProvider({ children }: { children: ReactNode }) {
  const [inventory, setInventory] = useState<Ingredient[]>(() => load(KEYS.inventory, []))
  const [settings, setSettingsState] = useState<Settings>(() => ({ ...DEFAULT_SETTINGS, ...load<Partial<Settings>>(KEYS.settings, {}) }))
  const [result, setResultState] = useState<RecResult | null>(() => load(KEYS.result, null))
  const [ai, setAi] = useState<AiStatus & { checked: boolean }>({ available: false, checked: false })
  const [toast, setToast] = useState<string | null>(null)

  useEffect(() => save(KEYS.inventory, inventory), [inventory])
  useEffect(() => save(KEYS.settings, settings), [settings])
  useEffect(() => save(KEYS.result, result), [result])
  useEffect(() => {
    fetchAiStatus().then((s) => setAi({ ...s, checked: true }))
  }, [])

  const showToast = useCallback((msg: string) => {
    setToast(msg)
    window.clearTimeout((showToast as any)._t)
    ;(showToast as any)._t = window.setTimeout(() => setToast(null), 2400)
  }, [])

  const value = useMemo<Store>(
    () => ({
      inventory,
      addIngredient: (i) => setInventory((prev) => [...prev, { ...i, id: uid(), createdAt: Date.now() }]),
      addMany: (list) => setInventory((prev) => [...prev, ...list.map((i) => ({ ...i, id: uid(), createdAt: Date.now() }))]),
      updateIngredient: (id, patch) => setInventory((prev) => prev.map((x) => (x.id === id ? { ...x, ...patch } : x))),
      removeIngredient: (id) => setInventory((prev) => prev.filter((x) => x.id !== id)),
      removeMany: (ids) => setInventory((prev) => prev.filter((x) => !ids.includes(x.id))),
      settings,
      setSettings: setSettingsState,
      result,
      setResult: setResultState,
      ai,
      useAi: ai.available && !settings.forceDemo,
      toast,
      showToast,
    }),
    [inventory, settings, result, ai, toast, showToast],
  )
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>
}

export function useStore() {
  const v = useContext(Ctx)
  if (!v) throw new Error('StoreProvider missing')
  return v
}

/* ── 아주 작은 해시 라우터 (Vercel에서 별도 설정 없이 새로고침 가능) ── */
export function useRoute() {
  const get = () => window.location.hash.replace(/^#/, '') || '/'
  const [path, setPath] = useState(get)
  useEffect(() => {
    const on = () => {
      setPath(get())
      window.scrollTo({ top: 0 })
    }
    window.addEventListener('hashchange', on)
    return () => window.removeEventListener('hashchange', on)
  }, [])
  return path
}

export function navigate(path: string) {
  window.location.hash = path
}
