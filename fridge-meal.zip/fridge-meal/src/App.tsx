import { Home, Refrigerator, Sparkles, Settings as SettingsIcon, CheckCircle2 } from 'lucide-react'
import { navigate, useRoute, useStore } from './store'
import { Logo, ModeBadge } from './components/bits'
import { cx } from './components/ui'
import { HomePage } from './pages/Home'
import { FridgePage } from './pages/Fridge'
import { RecommendPage } from './pages/Recommend'
import { RecipeDetailPage } from './pages/RecipeDetail'
import { SettingsPage } from './pages/Settings'
import { Onboarding } from './pages/Onboarding'

const NAV = [
  { path: '/', label: '홈', icon: Home },
  { path: '/fridge', label: '냉장고 관리', short: '냉장고', icon: Refrigerator },
  { path: '/recommend', label: '메뉴 추천', icon: Sparkles },
  { path: '/settings', label: '사용자 설정', short: '설정', icon: SettingsIcon },
]

export default function App() {
  const path = useRoute()
  const { settings, toast, inventory } = useStore()

  if (!settings.onboarded) return <Onboarding />

  const section = path.startsWith('/recipe') ? '/recommend' : '/' + (path.split('/')[1] ?? '')
  let page
  if (path === '/fridge' || path === '/fridge/add') page = <FridgePage openAdd={path === '/fridge/add'} />
  else if (path === '/recommend' || path === '/recommend/run') page = <RecommendPage autoRun={path === '/recommend/run'} />
  else if (path.startsWith('/recipe/')) page = <RecipeDetailPage id={decodeURIComponent(path.slice(8))} />
  else if (path === '/settings') page = <SettingsPage />
  else page = <HomePage />

  return (
    <div className="min-h-dvh">
      <header className="sticky top-0 z-40 border-b border-stone-200/70 bg-paper/90 backdrop-blur-md">
        <div className="mx-auto flex h-16 max-w-6xl items-center gap-6 px-4 sm:px-6">
          <button onClick={() => navigate('/')} className="flex items-center gap-2.5" aria-label="냉장고 한 끼 홈">
            <Logo />
            <span className="text-[16.5px] font-bold tracking-tight">냉장고 한 끼</span>
          </button>
          <nav className="hidden items-center gap-1 md:flex" aria-label="주요 메뉴">
            {NAV.slice(1).map((n) => (
              <button
                key={n.path}
                onClick={() => navigate(n.path)}
                className={cx('relative h-9 rounded-lg px-3 text-[14px] font-medium transition-colors', section === n.path ? 'bg-white text-ink ring-1 ring-stone-200' : 'text-stone-500 hover:text-ink')}
              >
                {n.label}
                {n.path === '/fridge' && inventory.length > 0 && <span className="ml-1.5 text-[12px] text-stone-400 tabular-nums">{inventory.length}</span>}
              </button>
            ))}
          </nav>
          <div className="ml-auto">
            <ModeBadge />
          </div>
        </div>
      </header>

      <main className="px-4 pt-6 pb-28 sm:px-6 sm:pt-8 md:pb-16">{page}</main>

      {/* 모바일 하단 탭 */}
      <nav className="fixed inset-x-0 bottom-0 z-40 border-t border-stone-200 bg-white/95 pb-[env(safe-area-inset-bottom)] backdrop-blur-md md:hidden" aria-label="하단 메뉴">
        <div className="grid grid-cols-4">
          {NAV.map((n) => {
            const active = section === n.path
            return (
              <button key={n.path} onClick={() => navigate(n.path)} className={cx('flex h-16 flex-col items-center justify-center gap-1 text-[11px] font-medium', active ? 'text-sage-700' : 'text-stone-400')}>
                <n.icon size={21} strokeWidth={active ? 2.2 : 1.8} />
                {n.short ?? n.label}
              </button>
            )
          })}
        </div>
      </nav>

      {toast && (
        <div className="pointer-events-none fixed inset-x-0 bottom-[calc(5rem+env(safe-area-inset-bottom))] z-50 flex justify-center px-4 md:bottom-8" role="status">
          <div className="flex items-center gap-2 rounded-full bg-ink px-4 py-2.5 text-[13.5px] font-medium text-white shadow-lg">
            <CheckCircle2 size={16} className="text-sage-300" />
            {toast}
          </div>
        </div>
      )}
    </div>
  )
}
