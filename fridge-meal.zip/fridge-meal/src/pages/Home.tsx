import { useMemo } from 'react'
import { ArrowRight, Plus, Sparkles, AlertTriangle, CalendarClock, Ban, Refrigerator, Snowflake, Package, ChevronRight, Trash2 } from 'lucide-react'
import { navigate, useStore } from '../store'
import { Button, Card, cx } from '../components/ui'
import { ExpiryBadge, ModeBadge } from '../components/bits'
import { EmptyFridge } from './Fridge'
import { classify, type Classified } from '../lib/expiry'
import { STORAGE_LABEL, SKILL_LABELS } from '../lib/presets'
import type { StorageType } from '../types'

export function HomePage() {
  const { inventory, settings, removeMany, showToast, useAi } = useStore()
  const all = useMemo(() => classify(inventory), [inventory])
  const today = all.filter((c) => c.status === 'today')
  const urgent = all.filter((c) => c.status === 'urgent')
  const expired = all.filter((c) => c.status === 'expired')
  const valid = all.filter((c) => c.status !== 'expired')
  const priority = [...today, ...urgent]

  return (
    <div className="mx-auto max-w-6xl">
      {/* ── Hero ── */}
      <section className="grid gap-5 lg:grid-cols-[1.25fr_1fr]">
        <div className="flex flex-col justify-center rounded-3xl bg-white px-6 py-8 ring-1 ring-stone-200/80 sm:px-9 sm:py-10">
          <div className="mb-4 flex items-center gap-2">
            <ModeBadge />
            <span className="text-[12.5px] text-stone-500">
              {SKILL_LABELS[settings.skill]} · {settings.maxTime}분 이내 · 구매 {settings.canBuy ? '최대 3개' : '없이'}
            </span>
          </div>
          <h1 className="text-[28px] leading-[1.25] font-bold tracking-tight text-balance sm:text-[36px]">
            오늘 냉장고에는
            <br />뭐가 남아 있나요?
          </h1>
          <p className="mt-3 max-w-md text-[15px] leading-relaxed text-stone-600">
            식재료와 소비기한을 적어 두면, 먼저 써야 할 재료를 골라 내 실력과 시간에 맞는 한 끼를 추천해 드려요.
          </p>
          <div className="mt-7 flex flex-col gap-2 sm:flex-row">
            <Button size="lg" variant="secondary" onClick={() => navigate('/fridge/add')}>
              <Plus size={17} />
              냉장고 식재료 등록
            </Button>
            <Button size="lg" onClick={() => navigate('/recommend/run')} disabled={!valid.length}>
              <Sparkles size={17} />
              {useAi ? 'AI 메뉴 추천' : '맞춤 메뉴 추천'}
            </Button>
          </div>
          <ol className="mt-8 grid grid-cols-3 gap-2 border-t border-stone-100 pt-5 text-[12.5px] text-stone-500">
            {['식재료·소비기한 입력', '우선 소비 재료 확인', '맞춤 메뉴 & 조리법'].map((t, i) => (
              <li key={t} className="flex flex-col gap-1 sm:flex-row sm:items-center sm:gap-2">
                <span className="grid size-6 shrink-0 place-items-center rounded-full bg-sage-100 text-[12px] font-bold text-sage-700">{i + 1}</span>
                {t}
              </li>
            ))}
          </ol>
        </div>

        {/* ── 오늘의 냉장고 ── */}
        <Card className="flex flex-col p-6">
          <div className="flex items-center justify-between">
            <h2 className="text-[16px] font-bold">오늘의 냉장고</h2>
            <button onClick={() => navigate('/fridge')} className="inline-flex items-center gap-0.5 text-[13px] font-medium text-stone-500 hover:text-ink">
              전체 보기 <ChevronRight size={15} />
            </button>
          </div>
          <div className="mt-4 grid grid-cols-3 gap-2">
            <Stat label="보유 식재료" value={valid.length} />
            <Stat label="소비기한 임박" value={priority.length} tone={priority.length ? 'amber' : undefined} />
            <Stat label="기한 지남" value={expired.length} tone={expired.length ? 'stone' : undefined} />
          </div>
          <div className="mt-5 flex-1">
            <p className="mb-2 text-[12.5px] font-semibold text-stone-500">우선 소비해야 할 재료</p>
            {priority.length ? (
              <ul className="space-y-1.5">
                {priority.slice(0, 5).map((c) => (
                  <li key={c.item.id} className="flex items-center justify-between rounded-xl bg-paper px-3 py-2.5">
                    <span className="text-[14.5px] font-semibold">{c.item.name}</span>
                    <span className="flex items-center gap-2 text-[12.5px] text-stone-500">
                      {c.item.quantity}
                      {c.item.unit}
                      <ExpiryBadge days={c.days} />
                    </span>
                  </li>
                ))}
                {priority.length > 5 && <li className="px-1 text-[12.5px] text-stone-500">외 {priority.length - 5}개</li>}
              </ul>
            ) : (
              <p className="rounded-xl bg-paper px-3 py-4 text-[13.5px] text-stone-500">{valid.length ? '3일 안에 소비기한이 끝나는 재료가 없어요.' : '등록된 식재료가 없어요.'}</p>
            )}
          </div>
          <StorageSummary items={valid} />
        </Card>
      </section>

      {/* ── 소비기한 임박 ── */}
      {inventory.length === 0 ? (
        <div className="mt-6">
          <EmptyFridge onAdd={() => navigate('/fridge/add')} />
        </div>
      ) : (
        <section className="mt-10">
          <div className="mb-3 flex items-end justify-between">
            <div>
              <h2 className="text-[19px] font-bold tracking-tight">소비기한 임박 식재료</h2>
              <p className="mt-0.5 text-[13px] text-stone-500">날짜 기준으로 계산해요. 오늘까지인 재료는 추천 메뉴에 우선 사용돼요.</p>
            </div>
          </div>
          <div className="grid gap-3 md:grid-cols-3">
            <Bucket icon={<AlertTriangle size={16} />} tone="red" title="오늘까지" desc="오늘 꼭 사용해야 해요" items={today} />
            <Bucket icon={<CalendarClock size={16} />} tone="amber" title="1~3일 이내" desc="이번 며칠 안에 먼저 써요" items={urgent} />
            <Bucket
              icon={<Ban size={16} />}
              tone="stone"
              title="소비기한 지남"
              desc="추천에 사용하지 않아요"
              items={expired}
              action={
                expired.length > 0 && (
                  <Button
                    size="sm"
                    variant="ghost"
                    className="text-stone-500"
                    onClick={() => {
                      removeMany(expired.map((e) => e.item.id))
                      showToast('기한 지난 재료를 정리했어요.')
                    }}
                  >
                    <Trash2 size={13} />
                    정리
                  </Button>
                )
              }
            />
          </div>
          {valid.length > 0 && (
            <button
              onClick={() => navigate('/recommend/run')}
              className="mt-5 flex w-full items-center justify-between gap-3 rounded-2xl bg-sage-700 px-5 py-4 text-left text-white transition-colors hover:bg-sage-800"
            >
              <span>
                <span className="block text-[15.5px] font-bold">{priority.length ? `${priority[0].item.name}부터 쓰는 메뉴 추천받기` : '지금 재료로 메뉴 추천받기'}</span>
                <span className="mt-0.5 block text-[13px] text-sage-100">실력·시간·조리도구·알레르기 조건을 반영해 최대 3개를 골라 드려요</span>
              </span>
              <ArrowRight size={20} className="shrink-0" />
            </button>
          )}
        </section>
      )}
    </div>
  )
}

function Stat({ label, value, tone }: { label: string; value: number; tone?: 'amber' | 'stone' }) {
  return (
    <div className={cx('rounded-xl px-3 py-3', tone === 'amber' ? 'bg-amber-50' : tone === 'stone' ? 'bg-stone-100' : 'bg-sage-50')}>
      <div className={cx('text-[24px] leading-none font-bold tabular-nums', tone === 'amber' ? 'text-amber-800' : tone === 'stone' ? 'text-stone-600' : 'text-sage-800')}>{value}</div>
      <div className="mt-1.5 text-[12px] font-medium text-stone-600">{label}</div>
    </div>
  )
}

const ICONS: Record<StorageType, typeof Snowflake> = { fridge: Refrigerator, freezer: Snowflake, room: Package }
function StorageSummary({ items }: { items: Classified[] }) {
  if (!items.length) return null
  return (
    <div className="mt-5 border-t border-stone-100 pt-4">
      <p className="mb-2 text-[12.5px] font-semibold text-stone-500">냉장고 식재료 요약</p>
      <div className="space-y-1.5">
        {(['fridge', 'freezer', 'room'] as StorageType[]).map((s) => {
          const list = items.filter((c) => c.item.storage === s)
          if (!list.length) return null
          const Icon = ICONS[s]
          return (
            <div key={s} className="flex items-start gap-2 text-[13px]">
              <span className="inline-flex w-14 shrink-0 items-center gap-1 font-semibold text-stone-600">
                <Icon size={13} />
                {STORAGE_LABEL[s]}
              </span>
              <span className="text-stone-600">{list.map((c) => c.item.name).join(', ')}</span>
            </div>
          )
        })}
      </div>
    </div>
  )
}

function Bucket({ icon, title, desc, items, tone, action }: { icon: React.ReactNode; title: string; desc: string; items: Classified[]; tone: 'red' | 'amber' | 'stone'; action?: React.ReactNode }) {
  const t = { red: 'text-red-700 bg-red-50', amber: 'text-amber-800 bg-amber-50', stone: 'text-stone-600 bg-stone-100' }[tone]
  return (
    <Card className="p-5">
      <div className="flex items-start justify-between gap-2">
        <div className="flex items-center gap-2.5">
          <span className={cx('grid size-8 place-items-center rounded-lg', t)}>{icon}</span>
          <div>
            <h3 className="text-[15px] font-bold">
              {title} <span className="ml-0.5 text-stone-400 tabular-nums">{items.length}</span>
            </h3>
            <p className="text-[12px] text-stone-500">{desc}</p>
          </div>
        </div>
        {action}
      </div>
      {items.length ? (
        <ul className="mt-4 flex flex-wrap gap-1.5">
          {items.map((c) => (
            <li key={c.item.id} className={cx('inline-flex items-center gap-1.5 rounded-lg py-1 pr-1.5 pl-2.5 text-[13.5px] font-medium ring-1 ring-stone-200', tone === 'stone' ? 'bg-stone-50 text-stone-500 line-through decoration-stone-300' : 'bg-white')}>
              {c.item.name}
              <ExpiryBadge days={c.days} className="no-underline" />
            </li>
          ))}
        </ul>
      ) : (
        <p className="mt-4 text-[13px] text-stone-400">해당하는 재료가 없어요</p>
      )}
    </Card>
  )
}
