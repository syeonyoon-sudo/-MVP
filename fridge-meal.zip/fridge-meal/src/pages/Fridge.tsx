import { useEffect, useMemo, useState } from 'react'
import { Plus, Search, Snowflake, Refrigerator, Package, Pencil, Trash2, Sparkles, X, Check } from 'lucide-react'
import type { Ingredient, StorageType } from '../types'
import { navigate, useStore } from '../store'
import { Button, Card, Segmented, SectionTitle, cx, inputCls } from '../components/ui'
import { ExpiryBadge } from '../components/bits'
import { IngredientForm, draftFromQuick, emptyDraft } from '../components/IngredientForm'
import { Notice } from '../components/MenuCard'
import { josa } from '../lib/recommend'
import { addDays, classify, formatDate, STATUS_META, todayStr } from '../lib/expiry'
import { QUICK_ITEMS, SAMPLE_OFFSETS, SEASONINGS, STORAGE_LABEL } from '../lib/presets'

export const STORAGE_ICON: Record<StorageType, typeof Snowflake> = { fridge: Refrigerator, freezer: Snowflake, room: Package }

type Sort = 'expiry' | 'name' | 'recent'

export function FridgePage({ openAdd }: { openAdd?: boolean }) {
  const { inventory, addIngredient, updateIngredient, removeIngredient, removeMany, showToast, settings, setSettings } = useStore()
  const [q, setQ] = useState('')
  const [filter, setFilter] = useState<'all' | StorageType>('all')
  const [sort, setSort] = useState<Sort>('expiry')
  const [form, setForm] = useState<{ open: boolean; editing?: Ingredient; initial: ReturnType<typeof emptyDraft> }>({ open: false, initial: emptyDraft() })
  const [customSeason, setCustomSeason] = useState('')

  useEffect(() => {
    if (openAdd) {
      setForm({ open: true, initial: emptyDraft() })
      navigate('/fridge')
    }
  }, [openAdd])

  const all = useMemo(() => classify(inventory), [inventory])
  const expired = all.filter((c) => c.status === 'expired')
  const list = useMemo(() => {
    let l = all.filter((c) => (filter === 'all' || c.item.storage === filter) && c.item.name.replace(/\s/g, '').includes(q.replace(/\s/g, '')))
    if (sort === 'name') l = [...l].sort((a, b) => a.item.name.localeCompare(b.item.name, 'ko'))
    if (sort === 'recent') l = [...l].sort((a, b) => b.item.createdAt - a.item.createdAt)
    return l
  }, [all, filter, q, sort])

  const counts = { all: all.length, fridge: 0, freezer: 0, room: 0 } as Record<'all' | StorageType, number>
  all.forEach((c) => counts[c.item.storage]++)

  const close = () => setForm((f) => ({ ...f, open: false }))

  return (
    <div className="mx-auto max-w-6xl">
      <header className="mb-6 flex flex-wrap items-end justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold tracking-tight sm:text-[28px]">냉장고 관리</h1>
          <p className="mt-1 text-[14px] text-stone-500">
            식재료 {all.length}개 · 소비기한이 가까운 순서로 보여드려요
          </p>
        </div>
        <Button onClick={() => setForm({ open: true, initial: emptyDraft() })}>
          <Plus size={16} />
          식재료 추가
        </Button>
      </header>

      <Card className="mb-5 p-4 sm:p-5">
        <div className="mb-2.5 flex items-center justify-between">
          <h2 className="text-[14px] font-bold">자주 쓰는 식재료 빠르게 추가</h2>
          <span className="hidden text-[12px] text-stone-500 sm:inline">누르면 수량·기한이 미리 채워져요</span>
        </div>
        <div className="no-scrollbar -mx-1 flex gap-1.5 overflow-x-auto px-1 pb-1 sm:flex-wrap">
          {QUICK_ITEMS.map((qi) => (
            <button
              key={qi.name}
              onClick={() => setForm({ open: true, initial: draftFromQuick(qi.name) })}
              className="inline-flex h-9 shrink-0 items-center gap-1 rounded-full bg-paper px-3.5 text-[13.5px] font-medium text-stone-700 ring-1 ring-stone-200 hover:bg-sage-50 hover:ring-sage-300"
            >
              <Plus size={13} className="text-sage-600" />
              {qi.name}
            </button>
          ))}
        </div>
      </Card>

      {expired.length > 0 && (
        <div className="mb-5">
          <Notice tone="danger">
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span>
                소비기한이 지난 재료 <b>{expired.map((e) => e.item.name).join(', ')}</b>{josa(expired[expired.length - 1].item.name, '은', '는')} 메뉴 추천에 사용하지 않아요. 섭취하지 말고 정리해 주세요.
              </span>
              <Button
                size="sm"
                variant="danger"
                onClick={() => {
                  if (confirm(`기한이 지난 ${expired.length}개 재료를 삭제할까요?`)) {
                    removeMany(expired.map((e) => e.item.id))
                    showToast('기한 지난 재료를 정리했어요.')
                  }
                }}
              >
                모두 삭제
              </Button>
            </div>
          </Notice>
        </div>
      )}

      <div className="mb-4 flex flex-col gap-2.5 sm:flex-row sm:items-center">
        <div className="relative flex-1">
          <Search size={16} className="pointer-events-none absolute top-1/2 left-3.5 -translate-y-1/2 text-stone-400" />
          <input className={cx(inputCls, 'pl-10')} placeholder="식재료 검색" value={q} onChange={(e) => setQ(e.target.value)} />
          {q && (
            <button onClick={() => setQ('')} className="absolute top-1/2 right-2 grid size-7 -translate-y-1/2 place-items-center rounded-full text-stone-400 hover:bg-stone-100" aria-label="검색어 지우기">
              <X size={14} />
            </button>
          )}
        </div>
        <Segmented
          className="sm:w-[340px]"
          value={filter}
          onChange={setFilter}
          options={[
            { value: 'all', label: `전체 ${counts.all}` },
            { value: 'fridge', label: `냉장 ${counts.fridge}` },
            { value: 'freezer', label: `냉동 ${counts.freezer}` },
            { value: 'room', label: `실온 ${counts.room}` },
          ]}
        />
        <select className={cx(inputCls, 'sm:w-36')} value={sort} onChange={(e) => setSort(e.target.value as Sort)} aria-label="정렬">
          <option value="expiry">소비기한순</option>
          <option value="name">이름순</option>
          <option value="recent">최근 등록순</option>
        </select>
      </div>

      {all.length === 0 ? (
        <EmptyFridge onAdd={() => setForm({ open: true, initial: emptyDraft() })} />
      ) : list.length === 0 ? (
        <Card className="py-14 text-center text-[14px] text-stone-500">조건에 맞는 식재료가 없어요.</Card>
      ) : (
        <ul className="grid gap-2.5 sm:grid-cols-2 lg:grid-cols-3">
          {list.map(({ item, days, status }) => {
            const Icon = STORAGE_ICON[item.storage]
            return (
              <li key={item.id}>
                <div className={cx('group relative flex items-center gap-3 rounded-2xl bg-white p-3.5 pl-4 ring-1 ring-stone-200/80 transition-shadow hover:ring-stone-300', status === 'expired' && 'bg-stone-50')}>
                  <span className={cx('absolute top-3.5 bottom-3.5 left-0 w-1 rounded-r-full', STATUS_META[status].dot)} />
                  <button className="min-w-0 flex-1 text-left" onClick={() => setForm({ open: true, editing: item, initial: { name: item.name, quantity: item.quantity, unit: item.unit, expiry: item.expiry, storage: item.storage } })}>
                    <div className="flex items-center gap-2">
                      <span className={cx('truncate text-[15px] font-semibold', status === 'expired' && 'text-stone-500 line-through decoration-stone-400')}>{item.name}</span>
                      <ExpiryBadge days={days} />
                    </div>
                    <div className="mt-1 flex items-center gap-2 text-[12.5px] text-stone-500">
                      <span className="inline-flex items-center gap-1">
                        <Icon size={13} />
                        {STORAGE_LABEL[item.storage]}
                      </span>
                      <span>·</span>
                      <span>
                        {item.quantity}
                        {item.unit}
                      </span>
                      <span>·</span>
                      <span>{formatDate(item.expiry)}까지</span>
                    </div>
                  </button>
                  <div className="flex shrink-0 gap-0.5">
                    <button
                      className="grid size-9 place-items-center rounded-lg text-stone-400 hover:bg-stone-100 hover:text-ink"
                      aria-label={`${item.name} 수정`}
                      onClick={() => setForm({ open: true, editing: item, initial: { name: item.name, quantity: item.quantity, unit: item.unit, expiry: item.expiry, storage: item.storage } })}
                    >
                      <Pencil size={15} />
                    </button>
                    <button
                      className="grid size-9 place-items-center rounded-lg text-stone-400 hover:bg-red-50 hover:text-red-600"
                      aria-label={`${item.name} 삭제`}
                      onClick={() => {
                        removeIngredient(item.id)
                        showToast(`${item.name}${josa(item.name, '을', '를')} 삭제했어요.`)
                      }}
                    >
                      <Trash2 size={15} />
                    </button>
                  </div>
                </div>
              </li>
            )
          })}
        </ul>
      )}

      <section className="mt-10">
        <SectionTitle title="보유 양념" desc="체크한 양념은 '추가 구매 재료' 개수에서 빠져요." />
        <Card className="p-4 sm:p-5">
          <div className="flex flex-wrap gap-1.5">
            {[...SEASONINGS, ...settings.pantry.filter((p) => !SEASONINGS.includes(p))].map((sname) => {
              const on = settings.pantry.includes(sname)
              return (
                <button
                  key={sname}
                  onClick={() => setSettings({ ...settings, pantry: on ? settings.pantry.filter((p) => p !== sname) : [...settings.pantry, sname] })}
                  className={cx('inline-flex h-9 items-center gap-1 rounded-full px-3.5 text-[13.5px] font-medium transition-colors', on ? 'bg-sage-100 text-sage-800 ring-1 ring-sage-300' : 'bg-white text-stone-500 ring-1 ring-stone-200 hover:ring-stone-300')}
                  aria-pressed={on}
                >
                  {on && <Check size={13} />}
                  {sname}
                </button>
              )
            })}
          </div>
          <form
            className="mt-3 flex gap-2"
            onSubmit={(e) => {
              e.preventDefault()
              const t = customSeason.trim()
              if (t && !settings.pantry.includes(t)) setSettings({ ...settings, pantry: [...settings.pantry, t] })
              setCustomSeason('')
            }}
          >
            <input className={cx(inputCls, 'h-10 max-w-xs')} placeholder="다른 양념 추가 (예: 올리고당)" value={customSeason} onChange={(e) => setCustomSeason(e.target.value)} />
            <Button type="submit" variant="secondary" disabled={!customSeason.trim()}>
              추가
            </Button>
          </form>
        </Card>
      </section>

      {all.length > 0 && (
        <div className="mt-8 flex justify-center">
          <Button size="lg" onClick={() => navigate('/recommend/run')}>
            <Sparkles size={17} />이 재료로 메뉴 추천받기
          </Button>
        </div>
      )}

      <IngredientForm
        open={form.open}
        initial={form.initial}
        editing={!!form.editing}
        onClose={close}
        onSubmit={(d) => {
          if (form.editing) {
            updateIngredient(form.editing.id, d)
            showToast(`${d.name} 정보를 수정했어요.`)
          } else {
            addIngredient(d)
            showToast(`${d.name}${josa(d.name, '을', '를')} 냉장고에 넣었어요.`)
          }
          close()
        }}
        onDelete={
          form.editing
            ? () => {
                removeIngredient(form.editing!.id)
                showToast(`${form.editing!.name}${josa(form.editing!.name, '을', '를')} 삭제했어요.`)
                close()
              }
            : undefined
        }
      />
    </div>
  )
}

export function EmptyFridge({ onAdd }: { onAdd: () => void }) {
  const { addMany, showToast } = useStore()
  return (
    <Card className="px-6 py-12 text-center">
      <span className="mx-auto grid size-14 place-items-center rounded-2xl bg-sage-100 text-sage-700">
        <Refrigerator size={26} strokeWidth={1.6} />
      </span>
      <h3 className="mt-4 text-[17px] font-bold">냉장고가 비어 있어요</h3>
      <p className="mx-auto mt-1 max-w-sm text-[14px] text-stone-500">지금 냉장고에 있는 식재료와 소비기한을 등록하면, 먼저 써야 할 재료로 만들 수 있는 메뉴를 추천해 드려요.</p>
      <div className="mt-5 flex flex-wrap justify-center gap-2">
        <Button onClick={onAdd}>
          <Plus size={16} />첫 식재료 등록하기
        </Button>
        <SampleButton onLoad={(list) => { addMany(list); showToast('예시 식재료 9개를 넣었어요. 언제든 삭제할 수 있어요.') }} />
      </div>
    </Card>
  )
}

export function SampleButton({ onLoad }: { onLoad: (l: Omit<Ingredient, 'id' | 'createdAt'>[]) => void }) {
  return (
    <Button variant="secondary" onClick={() => onLoad(SAMPLE_OFFSETS.map((s) => ({ name: s.name, quantity: s.quantity, unit: s.unit, storage: s.storage, expiry: addDays(todayStr(), s.offset) })))}>
      예시 식재료로 체험하기
    </Button>
  )
}
