import { useEffect, useMemo, useRef, useState } from 'react'
import { RefreshCw, Sparkles, SlidersHorizontal, Shuffle, Loader2, Info, Refrigerator, Wrench, Clock, ShoppingBasket, ChefHat } from 'lucide-react'
import type { Ingredient, RecResult, Settings } from '../types'
import { navigate, useStore } from '../store'
import { Button, Card } from '../components/ui'
import { ExpiryBadge, ModeBadge } from '../components/bits'
import { MenuCard, Notice } from '../components/MenuCard'
import { josa, recommendDemo } from '../lib/recommend'
import { recommendAI } from '../lib/ai'
import { classify, todayStr } from '../lib/expiry'
import { SKILL_LABELS } from '../lib/presets'
import { RECIPES } from '../lib/recipes'

export function inputKeyOf(inv: Ingredient[], s: Settings) {
  const { onboarded, ...rest } = s
  return JSON.stringify([todayStr(), inv.map((i) => [i.name, i.quantity, i.expiry, i.storage]), rest])
}

export function RecommendPage({ autoRun }: { autoRun?: boolean }) {
  const { inventory, settings, result, setResult, useAi, ai } = useStore()
  const [loading, setLoading] = useState(false)
  const ran = useRef(false)
  const all = useMemo(() => classify(inventory), [inventory])
  const valid = all.filter((c) => c.status !== 'expired')
  const today = all.filter((c) => c.status === 'today')
  const urgent = all.filter((c) => c.status === 'urgent')
  const key = inputKeyOf(inventory, settings)
  const stale = !!result && result.inputKey !== key

  const run = async (rotate = false) => {
    if (!valid.length) return
    const exclude = rotate && result ? result.shownIds : []
    setLoading(true)
    let r: RecResult
    if (useAi) {
      const prevNames = rotate && result ? result.menus.map((m) => m.recipe.name) : []
      r = await recommendAI(inventory, settings, exclude, prevNames)
    } else {
      await new Promise((res) => setTimeout(res, 350)) // 결과가 바뀌었음을 인지할 수 있도록 짧은 전환
      r = recommendDemo(inventory, settings, exclude)
    }
    setResult({ ...r, inputKey: key })
    setLoading(false)
  }

  useEffect(() => {
    if (!autoRun || ran.current || !ai.checked) return
    ran.current = true
    navigate('/recommend')
    if (!result || result.inputKey !== key) run()
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [autoRun, ai.checked])

  return (
    <div className="mx-auto max-w-6xl">
      <header className="mb-6 flex flex-wrap items-end justify-between gap-4">
        <div>
          <div className="mb-2">
            <ModeBadge />
          </div>
          <h1 className="text-2xl font-bold tracking-tight sm:text-[28px]">오늘의 맞춤 메뉴</h1>
          <p className="mt-1 text-[14px] text-stone-500">먼저 써야 할 재료와 내 조건을 함께 따져 골랐어요.</p>
        </div>
        <div className="flex gap-2">
          {result && result.menus.length > 0 && (
            <Button variant="secondary" onClick={() => run(true)} disabled={loading || !valid.length}>
              <Shuffle size={15} />
              다른 메뉴 보기
            </Button>
          )}
          <Button onClick={() => run(false)} disabled={loading || !valid.length}>
            {loading ? <Loader2 size={16} className="animate-spin" /> : result ? <RefreshCw size={15} /> : <Sparkles size={16} />}
            {result ? '다시 추천' : '추천 받기'}
          </Button>
        </div>
      </header>

      {/* 조건 요약 */}
      <div className="grid gap-3 lg:grid-cols-[1fr_1.2fr]">
        <Card className="p-5">
          <div className="mb-3 flex items-center justify-between">
            <h2 className="text-[14px] font-bold">추천 조건</h2>
            <button onClick={() => navigate('/settings')} className="inline-flex items-center gap-1 text-[13px] font-medium text-sage-700 hover:underline">
              <SlidersHorizontal size={13} />
              조건 변경
            </button>
          </div>
          <div className="grid grid-cols-2 gap-2 text-[13px]">
            <Cond icon={<ChefHat size={14} />} label="요리 실력" value={SKILL_LABELS[settings.skill]} />
            <Cond icon={<Clock size={14} />} label="조리 시간" value={`${settings.maxTime}분 이내`} />
            <Cond icon={<ShoppingBasket size={14} />} label="추가 구매" value={settings.canBuy ? '최대 3개' : '불가 (0개)'} />
            <Cond icon={<Wrench size={14} />} label="조리도구" value={settings.tools.length ? `${settings.tools.length}종` : '없음'} />
          </div>
          {settings.allergies.length > 0 && <p className="mt-3 text-[12.5px] text-stone-500">제외 재료: {settings.allergies.join(', ')}</p>}
        </Card>
        <Card className="p-5">
          <h2 className="mb-1 text-[14px] font-bold">우선 소비 판단</h2>
          <p className="mb-3 text-[12.5px] text-stone-500">AI 판단이 아니라 오늘 날짜와 소비기한으로 계산한 결과예요.</p>
          {today.length + urgent.length > 0 ? (
            <div className="flex flex-wrap gap-1.5">
              {[...today, ...urgent].map((c) => (
                <span key={c.item.id} className="inline-flex items-center gap-1.5 rounded-lg bg-paper py-1 pr-1.5 pl-2.5 text-[13.5px] font-medium ring-1 ring-stone-200">
                  {c.item.name}
                  <ExpiryBadge days={c.days} />
                </span>
              ))}
            </div>
          ) : (
            <p className="text-[13.5px] text-stone-500">{valid.length ? '3일 안에 소비기한이 끝나는 재료가 없어요. 보유 재료를 많이 쓰는 순서로 추천해요.' : '추천에 사용할 수 있는 식재료가 없어요.'}</p>
          )}
        </Card>
      </div>

      <div className="mt-8">
        {!valid.length ? (
          <Card className="px-6 py-14 text-center">
            <Refrigerator size={30} strokeWidth={1.5} className="mx-auto text-sage-600" />
            <h3 className="mt-3 text-[17px] font-bold">추천에 쓸 식재료가 없어요</h3>
            <p className="mt-1 text-[14px] text-stone-500">{all.length ? '등록된 재료가 모두 소비기한이 지났어요. 새 식재료를 등록해 주세요.' : '냉장고에 있는 식재료를 먼저 등록해 주세요.'}</p>
            <Button className="mt-5" onClick={() => navigate('/fridge/add')}>
              식재료 등록하기
            </Button>
          </Card>
        ) : loading ? (
          <LoadingState ai={useAi} />
        ) : !result ? (
          <Card className="px-6 py-14 text-center">
            <Sparkles size={28} strokeWidth={1.6} className="mx-auto text-sage-600" />
            <h3 className="mt-3 text-[17px] font-bold">추천 준비 완료</h3>
            <p className="mt-1 text-[14px] text-stone-500">보유 식재료 {valid.length}개로 만들 수 있는 메뉴를 찾아볼게요.</p>
            <Button className="mt-5" size="lg" onClick={() => run()}>
              <Sparkles size={16} />
              메뉴 추천 받기
            </Button>
          </Card>
        ) : (
          <ResultView result={result} stale={stale} onRerun={() => run()} />
        )}
      </div>

      {!useAi && (
        <p className="mt-10 flex items-start gap-2 rounded-xl bg-white px-4 py-3 text-[12.5px] leading-relaxed text-stone-500 ring-1 ring-stone-200">
          <Info size={14} className="mt-0.5 shrink-0" />
          데모 모드: AI API 없이 내장된 메뉴 {RECIPES.length}개와 추천 규칙(소비기한 → 알레르기 → 도구 → 시간 → 난이도 → 구매 개수 → 취향 순)으로 계산해요. 입력한 재료와 조건이 바뀌면 결과도 달라져요.
        </p>
      )}
    </div>
  )
}

function Cond({ icon, label, value }: { icon: React.ReactNode; label: string; value: string }) {
  return (
    <div className="rounded-xl bg-paper px-3 py-2.5">
      <div className="flex items-center gap-1 text-[11.5px] font-medium text-stone-500">
        {icon}
        {label}
      </div>
      <div className="mt-0.5 font-semibold">{value}</div>
    </div>
  )
}

function LoadingState({ ai }: { ai: boolean }) {
  return (
    <div>
      <p className="mb-4 flex items-center gap-2 text-[14px] text-stone-600">
        <Loader2 size={16} className="animate-spin text-sage-600" />
        {ai ? 'AI가 메뉴와 조리법을 작성하고 있어요. 20~40초 정도 걸릴 수 있어요.' : '조건에 맞는 메뉴를 고르는 중이에요.'}
      </p>
      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {[0, 1, 2].map((i) => (
          <Card key={i} className="h-[420px] animate-pulse p-5">
            <div className="flex gap-4">
              <div className="size-14 rounded-xl bg-stone-100" />
              <div className="flex-1 space-y-2 pt-1">
                <div className="h-3 w-16 rounded bg-stone-100" />
                <div className="h-5 w-3/4 rounded bg-stone-100" />
              </div>
            </div>
            <div className="mt-6 h-20 rounded-xl bg-stone-100" />
            <div className="mt-5 space-y-3">
              <div className="h-3 w-1/2 rounded bg-stone-100" />
              <div className="h-3 w-2/3 rounded bg-stone-100" />
            </div>
          </Card>
        ))}
      </div>
    </div>
  )
}

function ResultView({ result, stale, onRerun }: { result: RecResult; stale: boolean; onRerun: () => void }) {
  return (
    <div className="space-y-4">
      {stale && (
        <Notice tone="info">
          <div className="flex flex-wrap items-center justify-between gap-2">
            <span>냉장고 재료나 설정, 날짜가 바뀌었어요. 최신 상태로 다시 추천받아 보세요.</span>
            <Button size="sm" variant="soft" onClick={onRerun}>
              <RefreshCw size={13} />
              다시 추천
            </Button>
          </div>
        </Notice>
      )}
      {result.fallbackReason && <Notice tone="warn">{result.fallbackReason}</Notice>}

      {result.menus.length > 0 ? (
        <>
          <div className="flex items-center justify-between">
            <p className="text-[14px] text-stone-600">
              조건을 모두 만족하는 메뉴 <b className="text-ink">{result.menus.length}개</b>
              {result.menus.length < 3 && <span className="text-stone-500"> · 조건에 맞는 메뉴만 보여드려요</span>}
            </p>
            <span className="text-[12px] text-stone-400">{new Date(result.createdAt).toLocaleString('ko-KR', { month: 'numeric', day: 'numeric', hour: 'numeric', minute: '2-digit' })} 추천</span>
          </div>
          <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
            {result.menus.map((m, i) => (
              <MenuCard key={m.recipe.id} menu={m} rank={i + 1} />
            ))}
          </div>
        </>
      ) : (
        <Card className="px-6 py-12 text-center">
          <h3 className="text-[17px] font-bold">조건에 맞는 메뉴를 찾지 못했어요</h3>
          <p className="mx-auto mt-1.5 max-w-md text-[14px] text-stone-500">{result.emptyReason}</p>
          <div className="mt-5 flex justify-center gap-2">
            <Button variant="secondary" onClick={() => navigate('/settings')}>
              조건 변경
            </Button>
            <Button onClick={() => navigate('/fridge/add')}>식재료 추가</Button>
          </div>
        </Card>
      )}

      {result.todayUnused.length > 0 && (
        <Card className="p-5">
          <h3 className="text-[15px] font-bold text-red-800">오늘까지인 재료 중 추천에 쓰지 못한 재료</h3>
          <ul className="mt-3 space-y-3">
            {result.todayUnused.map((t) => (
              <li key={t.name} className="rounded-xl bg-red-50/60 px-4 py-3 text-[13.5px] leading-relaxed ring-1 ring-red-100">
                <b>{t.name}</b> — {t.reason}
                <p className="mt-1 text-stone-700">
                  <span className="font-semibold text-sage-800">대안 </span>
                  {t.alternative}
                </p>
              </li>
            ))}
          </ul>
        </Card>
      )}

      {result.expiredExcluded.length > 0 && <Notice tone="info">소비기한이 지난 {result.expiredExcluded.join(', ')}{josa(result.expiredExcluded[result.expiredExcluded.length - 1], '은', '는')} 추천 재료에서 제외했어요. 섭취하지 마세요.</Notice>}
    </div>
  )
}
