import { useMemo, useState } from 'react'
import { ArrowLeft, Check, Clock, ShieldAlert, ShoppingBasket, Wrench, CircleCheckBig, Sparkles, Timer } from 'lucide-react'
import type { MenuRec } from '../types'
import { navigate, useStore } from '../store'
import { Badge, Button, Card, Sheet, cx } from '../components/ui'
import { DifficultyDots, ExpiryBadge, MenuVisual } from '../components/bits'
import { analyze, buildContext, toMenuRec, writeReason } from '../lib/recommend'
import { getRecipeById } from '../lib/recipes'
import { classify } from '../lib/expiry'
import { keysOf, nameMatches } from '../lib/match'

export function RecipeDetailPage({ id }: { id: string }) {
  const { result, inventory, settings, removeMany, showToast } = useStore()
  const [done, setDone] = useState<number[]>([])
  const [cleanup, setCleanup] = useState(false)
  const [picked, setPicked] = useState<string[]>([])

  const menu: MenuRec | null = useMemo(() => {
    const fromResult = result?.menus.find((m) => m.recipe.id === id)
    if (fromResult) return fromResult
    const r = getRecipeById(id)
    if (!r) return null
    const ctx = buildContext(inventory, settings)
    const a = analyze(r, ctx)
    return toMenuRec(a, 'demo', writeReason(a, ctx))
  }, [id, result, inventory, settings])

  // 이 메뉴에 쓰이는 실제 냉장고 재료 (요리 후 정리용)
  const usedItems = useMemo(() => {
    if (!menu) return []
    const valid = classify(inventory).filter((c) => c.status !== 'expired')
    const out = new Map<string, (typeof valid)[number]>()
    for (const ing of menu.recipe.ingredients) {
      if (ing.kind !== 'main') continue
      const hit = valid.find((c) => nameMatches(c.item.name, keysOf(ing)))
      if (hit) out.set(hit.item.id, hit)
    }
    return [...out.values()]
  }, [menu, inventory])

  if (!menu) {
    return (
      <Card className="mx-auto max-w-xl px-6 py-14 text-center">
        <h1 className="text-[18px] font-bold">조리법을 찾을 수 없어요</h1>
        <p className="mt-1 text-[14px] text-stone-500">추천 결과가 새로 바뀌었거나 만료된 메뉴예요.</p>
        <Button className="mt-5" onClick={() => navigate('/recommend')}>
          추천 메뉴로 돌아가기
        </Button>
      </Card>
    )
  }

  const r = menu.recipe
  const ownedSet = new Set([...menu.owned, ...menu.optionalOwned, ...menu.ownedSeasonings])
  const buySet = new Set(menu.toBuy.map((t) => t.name))
  const mains = r.ingredients.filter((i) => i.kind === 'main')
  const seasonings = r.ingredients.filter((i) => i.kind === 'seasoning')
  const progress = r.steps.length ? Math.round((done.length / r.steps.length) * 100) : 0
  const cautions = [
    ...r.tips,
    ...(menu.priorityUsed.length ? ['소비기한이 임박한 재료는 조리 전에 냄새·색·끈적임을 확인하고, 이상하면 기한과 관계없이 사용하지 마세요.'] : []),
    '소비기한이 지난 재료는 이 조리법에 사용하지 않아요.',
  ]

  return (
    <div className="mx-auto max-w-5xl">
      <button onClick={() => (history.length > 1 ? history.back() : navigate('/recommend'))} className="mb-5 inline-flex items-center gap-1.5 text-[14px] font-medium text-stone-500 hover:text-ink">
        <ArrowLeft size={16} />
        추천 메뉴로
      </button>

      {/* 헤더 */}
      <Card className="p-5 sm:p-7">
        <div className="flex flex-col gap-5 sm:flex-row sm:items-start">
          <MenuVisual recipe={r} size="lg" />
          <div className="min-w-0 flex-1">
            <div className="flex flex-wrap items-center gap-1.5 text-[12.5px] font-semibold text-stone-500">
              {r.category}
              {menu.source === 'ai' ? (
                <Badge className="bg-sage-50 text-sage-700 ring-1 ring-sage-200">
                  <Sparkles size={11} />
                  AI가 작성한 조리법
                </Badge>
              ) : (
                <Badge className="bg-amber-50 text-amber-800 ring-1 ring-amber-200">데모 · 내장 조리법</Badge>
              )}
            </div>
            <h1 className="mt-1 text-[26px] leading-tight font-bold tracking-tight sm:text-[30px]">{r.name}</h1>
            <div className="mt-3 flex flex-wrap gap-2 text-[13px]">
              <Meta icon={<Clock size={14} />} label="예상 조리시간" value={`${r.time}분`} />
              <Meta icon={<Timer size={14} />} label="난이도" value={<DifficultyDots level={r.difficulty} />} />
              <Meta icon={<Wrench size={14} />} label="조리도구" value={r.tools.join(', ') || '없음'} />
              <Meta icon={<ShoppingBasket size={14} />} label="추가 구매" value={`${menu.toBuy.length}개`} />
            </div>
          </div>
        </div>
        {menu.reason && (
          <div className="mt-5 rounded-xl bg-paper px-4 py-3.5">
            <p className="mb-1 text-[12px] font-semibold text-sage-700">추천 이유</p>
            <p className="text-[14px] leading-relaxed text-stone-700">{menu.reason}</p>
          </div>
        )}
      </Card>

      <div className="mt-4 grid gap-4 lg:grid-cols-[340px_1fr]">
        {/* 재료 */}
        <div className="space-y-4">
          {menu.priorityUsed.length > 0 && (
            <Card className="p-5">
              <h2 className="text-[15px] font-bold">우선 소비 재료</h2>
              <ul className="mt-3 space-y-1.5">
                {menu.priorityUsed.map((p) => (
                  <li key={p.name} className="flex items-center justify-between rounded-lg bg-paper px-3 py-2 text-[14px] font-medium">
                    {p.name}
                    <ExpiryBadge days={p.daysLeft} />
                  </li>
                ))}
              </ul>
            </Card>
          )}
          <Card className="p-5">
            <div className="flex items-baseline justify-between">
              <h2 className="text-[15px] font-bold">재료</h2>
              <span className="text-[12px] text-stone-500">1인분 기준</span>
            </div>
            <IngList title="주재료" items={mains} ownedSet={ownedSet} buySet={buySet} />
            <IngList title="양념" items={seasonings} ownedSet={ownedSet} buySet={buySet} />
            <div className="mt-4 flex flex-wrap gap-3 border-t border-stone-100 pt-3 text-[11.5px] text-stone-500">
              <Legend cls="bg-sage-600" label="보유" />
              <Legend cls="bg-amber-500" label="추가 구매" />
              <Legend cls="bg-stone-300" label="선택 (없어도 됨)" />
            </div>
          </Card>
          {menu.toBuy.length > 0 && (
            <Card className="p-5">
              <h2 className="flex items-center gap-2 text-[15px] font-bold">
                <ShoppingBasket size={16} className="text-amber-600" />
                장보기 목록 <span className="text-stone-400">{menu.toBuy.length}</span>
              </h2>
              <ul className="mt-2 space-y-1 text-[14px]">
                {menu.toBuy.map((t) => (
                  <li key={t.name}>
                    · {t.name}
                    {t.kind === 'seasoning' && <span className="text-stone-500"> (양념)</span>}
                  </li>
                ))}
              </ul>
            </Card>
          )}
        </div>

        {/* 조리 순서 */}
        <div className="space-y-4">
          <Card className="p-5 sm:p-6">
            <div className="flex items-center justify-between">
              <h2 className="text-[17px] font-bold">조리 순서</h2>
              <span className="text-[12.5px] font-medium text-stone-500">
                {done.length}/{r.steps.length} 단계 완료
              </span>
            </div>
            <div className="mt-3 h-1.5 overflow-hidden rounded-full bg-stone-100">
              <div className="h-full rounded-full bg-sage-600 transition-[width]" style={{ width: `${progress}%` }} />
            </div>
            <ol className="mt-5 space-y-2">
              {r.steps.map((s, i) => {
                const on = done.includes(i)
                return (
                  <li key={i}>
                    <button
                      onClick={() => setDone((d) => (on ? d.filter((x) => x !== i) : [...d, i]))}
                      className={cx('flex w-full gap-3.5 rounded-xl p-3.5 text-left transition-colors', on ? 'bg-sage-50' : 'hover:bg-paper')}
                      aria-pressed={on}
                    >
                      <span className={cx('grid size-7 shrink-0 place-items-center rounded-full text-[13px] font-bold', on ? 'bg-sage-600 text-white' : 'bg-stone-100 text-stone-600')}>{on ? <Check size={14} /> : i + 1}</span>
                      <span className="min-w-0 flex-1">
                        <span className={cx('block text-[15px] leading-relaxed', on ? 'text-stone-400' : 'text-ink')}>{s.text}</span>
                        {s.minutes ? (
                          <span className="mt-1.5 inline-flex items-center gap-1 text-[12px] font-medium text-stone-500">
                            <Clock size={12} />약 {s.minutes}분
                          </span>
                        ) : null}
                      </span>
                    </button>
                  </li>
                )
              })}
            </ol>
          </Card>

          <Card className="p-5 sm:p-6">
            <h2 className="flex items-center gap-2 text-[15px] font-bold">
              <ShieldAlert size={16} className="text-amber-600" />
              조리 시 주의사항
            </h2>
            <ul className="mt-3 space-y-2 text-[14px] leading-relaxed text-stone-700">
              {cautions.map((c, i) => (
                <li key={i} className="flex gap-2">
                  <span className="mt-2 size-1 shrink-0 rounded-full bg-stone-400" />
                  {c}
                </li>
              ))}
            </ul>
          </Card>

          {usedItems.length > 0 && (
            <Button
              size="lg"
              className="w-full"
              variant={progress === 100 ? 'primary' : 'secondary'}
              onClick={() => {
                setPicked(usedItems.filter((c) => c.days <= 3).map((c) => c.item.id))
                setCleanup(true)
              }}
            >
              <CircleCheckBig size={17} />
              요리 완료 · 다 쓴 재료 정리하기
            </Button>
          )}
        </div>
      </div>

      <Sheet
        open={cleanup}
        onClose={() => setCleanup(false)}
        title="다 쓴 재료 정리"
        footer={
          <div className="flex gap-2">
            <Button variant="secondary" className="ml-auto" onClick={() => setCleanup(false)}>
              나중에
            </Button>
            <Button
              disabled={!picked.length}
              onClick={() => {
                removeMany(picked)
                showToast(`재료 ${picked.length}개를 냉장고에서 뺐어요.`)
                setCleanup(false)
                navigate('/')
              }}
            >
              {picked.length}개 냉장고에서 빼기
            </Button>
          </div>
        }
      >
        <p className="mb-3 text-[13.5px] text-stone-500">이번 요리로 모두 사용한 재료를 선택하세요. 남은 재료는 선택하지 않으면 그대로 유지돼요.</p>
        <ul className="space-y-1.5">
          {usedItems.map((c) => {
            const on = picked.includes(c.item.id)
            return (
              <li key={c.item.id}>
                <label className={cx('flex cursor-pointer items-center gap-3 rounded-xl px-3.5 py-3 ring-1', on ? 'bg-sage-50 ring-sage-300' : 'bg-white ring-stone-200')}>
                  <input type="checkbox" className="size-4.5 accent-sage-700" checked={on} onChange={() => setPicked((p) => (on ? p.filter((x) => x !== c.item.id) : [...p, c.item.id]))} />
                  <span className="flex-1 text-[14.5px] font-medium">
                    {c.item.name}{' '}
                    <span className="text-[12.5px] font-normal text-stone-500">
                      {c.item.quantity}
                      {c.item.unit}
                    </span>
                  </span>
                  <ExpiryBadge days={c.days} />
                </label>
              </li>
            )
          })}
        </ul>
      </Sheet>
    </div>
  )
}

function Meta({ icon, label, value }: { icon: React.ReactNode; label: string; value: React.ReactNode }) {
  return (
    <div className="rounded-xl bg-paper px-3 py-2">
      <div className="flex items-center gap-1 text-[11.5px] text-stone-500">
        {icon}
        {label}
      </div>
      <div className="mt-0.5 font-semibold text-ink">{value}</div>
    </div>
  )
}

function Legend({ cls, label }: { cls: string; label: string }) {
  return (
    <span className="inline-flex items-center gap-1.5">
      <span className={cx('size-2 rounded-full', cls)} />
      {label}
    </span>
  )
}

function IngList({ title, items, ownedSet, buySet }: { title: string; items: MenuRec['recipe']['ingredients']; ownedSet: Set<string>; buySet: Set<string> }) {
  if (!items.length) return null
  return (
    <div className="mt-4">
      <p className="mb-1.5 text-[12px] font-semibold text-stone-500">{title}</p>
      <ul className="divide-y divide-stone-100">
        {items.map((i) => {
          const owned = ownedSet.has(i.name)
          const buy = buySet.has(i.name)
          const dot = owned ? 'bg-sage-600' : buy ? 'bg-amber-500' : 'bg-stone-300'
          return (
            <li key={i.name} className="flex items-center gap-2.5 py-2 text-[14px]">
              <span className={cx('size-2 shrink-0 rounded-full', dot)} />
              <span className={cx('flex-1', !owned && !buy && 'text-stone-500')}>
                {i.name}
                {i.optional && <span className="ml-1 text-[11.5px] text-stone-400">선택</span>}
              </span>
              <span className="text-[13px] text-stone-500">{i.amount}</span>
              {owned ? <Badge className="bg-sage-50 text-sage-700">보유</Badge> : buy ? <Badge className="bg-amber-50 text-amber-800">구매</Badge> : <Badge className="bg-stone-100 text-stone-500">생략 가능</Badge>}
            </li>
          )
        })}
      </ul>
    </div>
  )
}
