import { useState } from 'react'
import { ArrowLeft, ArrowRight } from 'lucide-react'
import type { Settings } from '../types'
import { useStore } from '../store'
import { Button } from '../components/ui'
import { Logo } from '../components/bits'
import { ConditionSection, SkillSection, TasteSection, TimeSection } from '../components/SettingsSections'

const STEPS = [
  { title: '요리 실력이 어느 정도인가요?', desc: '실력에 맞는 난이도의 메뉴만 추천해 드려요.' },
  { title: '어떤 음식을 좋아하세요?', desc: '모두 선택 사항이에요. 나중에 설정에서 바꿀 수 있어요.' },
  { title: '조리 조건을 알려주세요', desc: '이 조건은 추천할 때 반드시 지켜요.' },
]

export function Onboarding() {
  const { settings, setSettings } = useStore()
  const [step, setStep] = useState(0)
  const [d, setD] = useState<Settings>(settings)
  const set = (p: Partial<Settings>) => setD((x) => ({ ...x, ...p }))
  const finish = (data: Settings) => setSettings({ ...data, onboarded: true })

  return (
    <div className="min-h-dvh bg-paper">
      <div className="mx-auto flex min-h-dvh max-w-xl flex-col px-5 pt-6 pb-[max(1.5rem,env(safe-area-inset-bottom))]">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Logo size={26} />
            <span className="text-[15px] font-bold">냉장고 한 끼</span>
          </div>
          <button onClick={() => finish(settings)} className="text-[13px] font-medium text-stone-500 hover:text-ink">
            건너뛰기
          </button>
        </div>

        <div className="mt-8 flex gap-1.5" aria-label={`${step + 1} / ${STEPS.length} 단계`}>
          {STEPS.map((_, i) => (
            <span key={i} className={`h-1 flex-1 rounded-full ${i <= step ? 'bg-sage-600' : 'bg-stone-200'}`} />
          ))}
        </div>
        <p className="mt-5 text-[13px] font-semibold text-sage-700">
          처음 설정 {step + 1}/{STEPS.length}
        </p>
        <h1 className="mt-1 text-[24px] leading-tight font-bold tracking-tight">{STEPS[step].title}</h1>
        <p className="mt-1.5 text-[14px] text-stone-500">{STEPS[step].desc}</p>

        <div className="mt-7 flex-1">
          {step === 0 && (
            <div className="space-y-7">
              <SkillSection s={d} set={set} />
              <TimeSection s={d} set={set} />
            </div>
          )}
          {step === 1 && <TasteSection s={d} set={set} />}
          {step === 2 && <ConditionSection s={d} set={set} />}
        </div>

        <div className="mt-8 flex gap-2">
          {step > 0 && (
            <Button variant="secondary" size="lg" onClick={() => setStep(step - 1)}>
              <ArrowLeft size={16} />
              이전
            </Button>
          )}
          <Button size="lg" className="flex-1" onClick={() => (step < STEPS.length - 1 ? setStep(step + 1) : finish(d))}>
            {step < STEPS.length - 1 ? '다음' : '시작하기'}
            <ArrowRight size={16} />
          </Button>
        </div>
      </div>
    </div>
  )
}
