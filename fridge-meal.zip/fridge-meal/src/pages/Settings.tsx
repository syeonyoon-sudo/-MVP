import { useEffect, useState, type ReactNode } from 'react'
import { ChefHat, Clock, Heart, Settings2, Sparkles, Database } from 'lucide-react'
import type { Settings as S } from '../types'
import { useStore } from '../store'
import { Button, Card } from '../components/ui'
import { ConditionSection, SkillSection, TasteSection, TimeSection } from '../components/SettingsSections'
import { ModeBadge } from '../components/bits'
import { DEFAULT_SETTINGS } from '../lib/presets'

function Block({ icon, title, desc, children }: { icon: ReactNode; title: string; desc: string; children: ReactNode }) {
  return (
    <Card className="p-5 sm:p-6">
      <div className="mb-5 flex items-start gap-3">
        <span className="grid size-9 shrink-0 place-items-center rounded-xl bg-sage-100 text-sage-700">{icon}</span>
        <div>
          <h2 className="text-[16px] font-bold">{title}</h2>
          <p className="text-[13px] text-stone-500">{desc}</p>
        </div>
      </div>
      {children}
    </Card>
  )
}

export function SettingsPage() {
  const { settings, setSettings, showToast, ai, inventory, removeMany, setResult } = useStore()
  const [draft, setDraft] = useState<S>(settings)
  useEffect(() => setDraft(settings), [settings])
  const dirty = JSON.stringify(draft) !== JSON.stringify(settings)
  const set = (patch: Partial<S>) => setDraft((d) => ({ ...d, ...patch }))

  const save = () => {
    setSettings({ ...draft, onboarded: true })
    showToast('설정을 저장했어요. 다음 추천부터 반영돼요.')
  }

  return (
    <div className="mx-auto max-w-3xl">
      <header className="mb-6">
        <h1 className="text-2xl font-bold tracking-tight sm:text-[28px]">사용자 설정</h1>
        <p className="mt-1 text-[14px] text-stone-500">요리 실력과 취향, 조리 조건을 알려주면 메뉴 추천에 그대로 반영돼요.</p>
      </header>

      <div className="space-y-4 pb-28">
        <Block icon={<ChefHat size={18} />} title="요리 실력" desc="실력보다 어려운 메뉴는 추천하지 않아요.">
          <SkillSection s={draft} set={set} />
        </Block>
        <Block icon={<Clock size={18} />} title="조리 조건" desc="시간·구매·도구·알레르기는 반드시 지키는 필수 조건이에요.">
          <div className="space-y-6">
            <TimeSection s={draft} set={set} />
            <ConditionSection s={draft} set={set} />
          </div>
        </Block>
        <Block icon={<Heart size={18} />} title="음식 취향" desc="필수 조건을 만족하는 메뉴 안에서 순위를 정할 때 반영돼요.">
          <TasteSection s={draft} set={set} />
        </Block>

        <Block icon={<Sparkles size={18} />} title="추천 모드" desc="AI 연결 상태와 추천 방식을 확인하세요.">
          <div className="flex flex-wrap items-center gap-2 text-[14px]">
            현재 상태 <ModeBadge />
          </div>
          {ai.available ? (
            <div className="mt-4 space-y-3">
              <p className="text-[13.5px] leading-relaxed text-stone-600">서버에 AI가 연결되어 있어요({ai.model}). 규칙으로 걸러낸 조건을 AI에게 전달하고, AI가 작성한 메뉴는 다시 한 번 규칙으로 검증해요.</p>
              <label className="flex cursor-pointer items-center justify-between gap-3 rounded-xl bg-paper px-4 py-3 ring-1 ring-stone-200">
                <span>
                  <span className="block text-[14px] font-semibold">데모 모드로 추천받기</span>
                  <span className="block text-[12.5px] text-stone-500">AI 대신 내장 메뉴 데이터와 규칙만 사용해요 (빠르고 비용 없음)</span>
                </span>
                <input type="checkbox" className="size-5 accent-sage-700" checked={draft.forceDemo} onChange={(e) => set({ forceDemo: e.target.checked })} />
              </label>
            </div>
          ) : (
            <p className="mt-4 text-[13.5px] leading-relaxed text-stone-600">
              AI API 키가 연결되지 않아 <b>데모 모드</b>로 동작해요. 데모 모드도 입력한 식재료·소비기한·설정을 실제로 계산해 내장된 메뉴 데이터에서 추천하며, 조리법은 미리 작성된 내용을 보여줘요. Vercel 환경변수에 <code className="rounded bg-stone-100 px-1">ANTHROPIC_API_KEY</code>를 추가하면 AI 추천 모드로 바뀌어요.
            </p>
          )}
        </Block>

        <Block icon={<Database size={18} />} title="데이터 관리" desc="모든 데이터는 이 브라우저(localStorage)에만 저장돼요.">
          <div className="flex flex-wrap gap-2">
            <Button
              variant="secondary"
              onClick={() => {
                if (confirm('설정을 처음 상태로 되돌릴까요?')) {
                  setSettings({ ...DEFAULT_SETTINGS, onboarded: true })
                  showToast('설정을 초기화했어요.')
                }
              }}
            >
              설정 초기화
            </Button>
            <Button
              variant="danger"
              onClick={() => {
                if (confirm(`냉장고 식재료 ${inventory.length}개와 추천 기록을 모두 삭제할까요?`)) {
                  removeMany(inventory.map((i) => i.id))
                  setResult(null)
                  showToast('냉장고를 비웠어요.')
                }
              }}
              disabled={!inventory.length}
            >
              냉장고 비우기
            </Button>
          </div>
        </Block>
      </div>

      {dirty && (
        <div className="fixed inset-x-0 bottom-[calc(4.25rem+env(safe-area-inset-bottom))] z-30 px-4 md:bottom-6">
          <div className="mx-auto flex max-w-3xl items-center gap-3 rounded-2xl bg-ink px-4 py-3 text-white shadow-lg">
            <Settings2 size={18} className="shrink-0 text-sage-300" />
            <span className="flex-1 text-[14px]">저장하지 않은 변경 사항이 있어요</span>
            <Button size="sm" variant="ghost" className="text-stone-300 hover:bg-white/10 hover:text-white" onClick={() => setDraft(settings)}>
              되돌리기
            </Button>
            <Button size="sm" className="bg-sage-500 hover:bg-sage-400" onClick={save}>
              저장
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}
