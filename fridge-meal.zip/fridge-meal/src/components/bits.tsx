import { Beef, CookingPot, Drumstick, Egg, Fish, Salad, Soup, UtensilsCrossed, Wheat, Sparkles, FlaskConical } from 'lucide-react'
import type { Recipe } from '../types'
import { STATUS_META, dLabel, statusOf } from '../lib/expiry'
import { Badge, cx } from './ui'
import { useStore } from '../store'

export function Logo({ size = 28 }: { size?: number }) {
  return (
    <svg width={size} height={size} viewBox="0 0 32 32" aria-hidden>
      <rect width="32" height="32" rx="9" fill="var(--color-sage-700)" />
      <rect x="10" y="6" width="12" height="20" rx="3" fill="none" stroke="#f8f7f3" strokeWidth="2" />
      <line x1="10" y1="13" x2="22" y2="13" stroke="#f8f7f3" strokeWidth="2" />
      <line x1="13" y1="9" x2="13" y2="11" stroke="#f8f7f3" strokeWidth="2" strokeLinecap="round" />
      <line x1="13" y1="16" x2="13" y2="19" stroke="#f8f7f3" strokeWidth="2" strokeLinecap="round" />
    </svg>
  )
}

export function ExpiryBadge({ days, className }: { days: number; className?: string }) {
  const st = statusOf(days)
  return <Badge className={cx(STATUS_META[st].badge, className)}>{dLabel(days)}</Badge>
}

const CAT_TONE: Record<string, string> = {
  한식: 'bg-sage-100 text-sage-700',
  양식: 'bg-amber-50 text-amber-700',
  중식: 'bg-rose-50 text-rose-700',
  일식: 'bg-sky-50 text-sky-700',
  분식: 'bg-orange-50 text-orange-700',
  샐러드: 'bg-lime-50 text-lime-700',
}

function iconFor(r: Recipe) {
  const n = r.name
  if (/찌개|국|탕|카레/.test(n)) return Soup
  if (/샐러드/.test(n)) return Salad
  if (/파스타|라면|면|떡볶이/.test(n)) return Wheat
  if (/닭/.test(n)) return Drumstick
  if (/소고기|불고기|스테이크|제육|돼지/.test(n)) return Beef
  if (/참치|어묵|생선/.test(n)) return Fish
  if (/계란|오믈렛/.test(n)) return Egg
  if (/볶음|조림|전/.test(n)) return CookingPot
  return UtensilsCrossed
}

export function MenuVisual({ recipe, size = 'md' }: { recipe: Recipe; size?: 'md' | 'lg' }) {
  const Icon = iconFor(recipe)
  const tone = CAT_TONE[recipe.category] ?? CAT_TONE['한식']
  return (
    <div className={cx('relative grid shrink-0 place-items-center overflow-hidden', tone, size === 'lg' ? 'size-20 rounded-2xl sm:size-24' : 'size-14 rounded-xl')}>
      <svg className="absolute inset-0 h-full w-full opacity-[0.12]" viewBox="0 0 40 40" aria-hidden>
        <circle cx="34" cy="6" r="14" fill="currentColor" />
        <circle cx="4" cy="38" r="9" fill="currentColor" />
      </svg>
      <Icon size={size === 'lg' ? 34 : 24} strokeWidth={1.6} className="relative" />
    </div>
  )
}

export function ModeBadge({ compact }: { compact?: boolean }) {
  const { ai, useAi } = useStore()
  if (!ai.checked) return <span className="h-6 w-16 animate-pulse rounded-full bg-stone-200/70" />
  return useAi ? (
    <span className="inline-flex h-6 items-center gap-1 rounded-full bg-sage-700 px-2.5 text-[11.5px] font-semibold text-white" title="서버에 연결된 AI가 메뉴와 조리법을 작성합니다">
      <Sparkles size={12} />
      {compact ? 'AI' : 'AI 추천 모드'}
    </span>
  ) : (
    <span className="inline-flex h-6 items-center gap-1 rounded-full bg-amber-100 px-2.5 text-[11.5px] font-semibold text-amber-900 ring-1 ring-amber-200" title="AI API 없이 내장된 메뉴 데이터와 규칙으로 추천합니다">
      <FlaskConical size={12} />
      {compact ? '데모' : '데모 모드'}
    </span>
  )
}

export const DIFF_LABEL = { 1: '초보', 2: '보통', 3: '숙련' } as const
export function DifficultyDots({ level }: { level: 1 | 2 | 3 }) {
  return (
    <span className="inline-flex items-center gap-1.5">
      <span className="flex gap-0.5">
        {[1, 2, 3].map((i) => (
          <span key={i} className={cx('h-1.5 w-3 rounded-full', i <= level ? 'bg-sage-600' : 'bg-stone-200')} />
        ))}
      </span>
      {DIFF_LABEL[level]}
    </span>
  )
}
