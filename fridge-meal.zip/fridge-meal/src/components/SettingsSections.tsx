import type { MaxTime, Settings, Skill } from '../types'
import { Chip, Field, Segmented, TagInput } from './ui'
import { FOOD_TYPES, SKILL_DESC, SKILL_LABELS, SPICY_LABELS, TASTES, TOOLS } from '../lib/presets'

type P = { s: Settings; set: (patch: Partial<Settings>) => void }

const toggle = (list: string[], v: string) => (list.includes(v) ? list.filter((x) => x !== v) : [...list, v])

export function SkillSection({ s, set }: P) {
  return (
    <div className="space-y-2">
      {([1, 2, 3] as Skill[]).map((k) => (
        <button
          key={k}
          type="button"
          onClick={() => set({ skill: k })}
          className={`flex w-full items-center gap-3 rounded-xl px-4 py-3 text-left transition-colors ${s.skill === k ? 'bg-sage-50 ring-2 ring-sage-500' : 'bg-white ring-1 ring-stone-200 hover:ring-sage-300'}`}
        >
          <span className={`grid size-5 shrink-0 place-items-center rounded-full ring-2 ${s.skill === k ? 'ring-sage-600' : 'ring-stone-300'}`}>{s.skill === k && <span className="size-2.5 rounded-full bg-sage-600" />}</span>
          <span>
            <span className="block text-[15px] font-semibold">{SKILL_LABELS[k]}</span>
            <span className="block text-[13px] text-stone-500">{SKILL_DESC[k]}</span>
          </span>
        </button>
      ))}
    </div>
  )
}

export function TimeSection({ s, set }: P) {
  return (
    <Field label="조리 가능 시간" hint="준비·손질 시간을 포함한 전체 시간이에요. 이 시간을 넘는 메뉴는 추천하지 않아요.">
      <Segmented<MaxTime> value={s.maxTime} onChange={(v) => set({ maxTime: v })} options={([10, 20, 30, 60] as MaxTime[]).map((t) => ({ value: t, label: `${t}분` }))} />
    </Field>
  )
}

export function TasteSection({ s, set }: P) {
  return (
    <div className="space-y-6">
      <Field label="선호 음식" hint="종류를 고르거나 좋아하는 음식·재료를 직접 입력하세요.">
        <div className="mb-2.5 flex flex-wrap gap-1.5">
          {FOOD_TYPES.map((f) => (
            <Chip key={f} active={s.likedFoods.includes(f)} onClick={() => set({ likedFoods: toggle(s.likedFoods, f) })}>
              {f}
            </Chip>
          ))}
        </div>
        <TagInput values={s.likedFoods.filter((f) => !FOOD_TYPES.includes(f))} onChange={(v) => set({ likedFoods: [...s.likedFoods.filter((f) => FOOD_TYPES.includes(f)), ...v] })} placeholder="예: 덮밥, 두부" />
      </Field>
      <Field label="비선호 음식" hint="싫어하는 메뉴나 재료는 추천 순위를 크게 낮춰요.">
        <TagInput values={s.dislikedFoods} onChange={(v) => set({ dislikedFoods: v })} placeholder="예: 버섯, 파스타" suggestions={['버섯', '양파', '당근', '찌개·국']} />
      </Field>
      <Field label="선호하는 맛">
        <div className="flex flex-wrap gap-1.5">
          {TASTES.map((t) => (
            <Chip key={t} active={s.tastes.includes(t)} onClick={() => set({ tastes: toggle(s.tastes, t) })}>
              {t}
            </Chip>
          ))}
        </div>
      </Field>
      <Field label="맵기 선호도">
        <Segmented value={s.spicy} onChange={(v) => set({ spicy: v })} options={([0, 1, 2, 3] as const).map((v) => ({ value: v, label: SPICY_LABELS[v].replace(' 맛', '') }))} />
      </Field>
    </div>
  )
}

export function ConditionSection({ s, set }: P) {
  return (
    <div className="space-y-6">
      <Field label="추가 구매 의향" hint={s.canBuy ? '필수 재료를 최대 3개(양념 포함)까지 사서 만드는 메뉴도 추천해요.' : '지금 있는 재료와 보유 양념만으로 만들 수 있는 메뉴만 추천해요.'}>
        <Segmented<'no' | 'yes'>
          value={s.canBuy ? 'yes' : 'no'}
          onChange={(v) => set({ canBuy: v === 'yes' })}
          options={[
            { value: 'no', label: '불가', sub: '구매 0개' },
            { value: 'yes', label: '가능', sub: '최대 3개' },
          ]}
        />
      </Field>
      <Field label="사용 가능한 조리도구" hint="선택하지 않은 도구가 필요한 메뉴는 추천하지 않아요.">
        <div className="flex flex-wrap gap-1.5">
          {TOOLS.map((t) => (
            <Chip key={t} active={s.tools.includes(t)} onClick={() => set({ tools: toggle(s.tools, t) })}>
              {t}
            </Chip>
          ))}
        </div>
      </Field>
      <Field label="알레르기 및 섭취 금기 재료" hint="입력한 재료와 그 재료가 들어간 양념(예: 우유 → 치즈·버터)까지 모두 제외해요.">
        <TagInput values={s.allergies} onChange={(v) => set({ allergies: v })} placeholder="예: 우유, 땅콩, 돼지고기" suggestions={['달걀', '우유', '밀', '대두', '땅콩', '갑각류', '생선', '돼지고기']} />
      </Field>
    </div>
  )
}
