import { useEffect, useState, type ButtonHTMLAttributes, type ReactNode } from 'react'
import { X, Plus } from 'lucide-react'

export const cx = (...c: (string | false | null | undefined)[]) => c.filter(Boolean).join(' ')

type Variant = 'primary' | 'secondary' | 'ghost' | 'danger' | 'soft'
export function Button({ variant = 'primary', size = 'md', className, ...p }: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: Variant; size?: 'sm' | 'md' | 'lg' }) {
  const v: Record<Variant, string> = {
    primary: 'bg-sage-700 text-white hover:bg-sage-800 shadow-sm shadow-sage-900/10',
    secondary: 'bg-white text-ink ring-1 ring-stone-200 hover:bg-stone-50 hover:ring-stone-300',
    soft: 'bg-sage-100 text-sage-800 hover:bg-sage-200',
    ghost: 'text-stone-600 hover:bg-stone-100 hover:text-ink',
    danger: 'bg-white text-red-700 ring-1 ring-red-200 hover:bg-red-50',
  }
  const s = { sm: 'h-8 px-3 text-[13px] gap-1.5 rounded-lg', md: 'h-10 px-4 text-sm gap-2 rounded-xl', lg: 'h-12 px-5 text-[15px] gap-2 rounded-xl' }[size]
  return (
    <button
      {...p}
      className={cx('inline-flex items-center justify-center font-semibold whitespace-nowrap transition-colors disabled:opacity-40 disabled:pointer-events-none focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-sage-500', v[variant], s, className)}
    />
  )
}

export function Card({ className, children }: { className?: string; children: ReactNode }) {
  return <div className={cx('rounded-2xl bg-white ring-1 ring-stone-200/80', className)}>{children}</div>
}

export function Badge({ className, children }: { className?: string; children: ReactNode }) {
  return <span className={cx('inline-flex items-center gap-1 rounded-md px-1.5 py-0.5 text-[11.5px] font-semibold leading-4 whitespace-nowrap', className)}>{children}</span>
}

export function Chip({ active, onClick, children, className }: { active?: boolean; onClick?: () => void; children: ReactNode; className?: string }) {
  return (
    <button
      type="button"
      onClick={onClick}
      aria-pressed={active}
      className={cx(
        'inline-flex h-9 items-center gap-1.5 rounded-full px-3.5 text-[13.5px] font-medium transition-colors',
        active ? 'bg-sage-700 text-white' : 'bg-white text-stone-700 ring-1 ring-stone-200 hover:ring-sage-300 hover:bg-sage-50',
        className,
      )}
    >
      {children}
    </button>
  )
}

export function Segmented<T extends string | number>({ value, options, onChange, className }: { value: T; options: { value: T; label: ReactNode; sub?: string }[]; onChange: (v: T) => void; className?: string }) {
  return (
    <div className={cx('grid gap-1 rounded-xl bg-stone-100 p-1', className)} style={{ gridTemplateColumns: `repeat(${options.length}, minmax(0,1fr))` }}>
      {options.map((o) => (
        <button
          key={String(o.value)}
          type="button"
          onClick={() => onChange(o.value)}
          className={cx('rounded-lg px-2 py-2 text-[13.5px] font-semibold transition-colors', value === o.value ? 'bg-white text-ink shadow-sm ring-1 ring-stone-200' : 'text-stone-500 hover:text-ink')}
        >
          {o.label}
          {o.sub && <span className="mt-0.5 block text-[11px] font-normal text-stone-500">{o.sub}</span>}
        </button>
      ))}
    </div>
  )
}

export function Field({ label, hint, children, className }: { label: string; hint?: string; children: ReactNode; className?: string }) {
  return (
    <label className={cx('block', className)}>
      <span className="mb-1.5 block text-[13px] font-semibold text-stone-700">{label}</span>
      {children}
      {hint && <span className="mt-1 block text-xs text-stone-500">{hint}</span>}
    </label>
  )
}

export const inputCls = 'w-full h-11 rounded-xl bg-white px-3.5 text-[15px] ring-1 ring-stone-200 placeholder:text-stone-400 focus:outline-none focus:ring-2 focus:ring-sage-400 transition-shadow'

export function Sheet({ open, onClose, title, children, footer }: { open: boolean; onClose: () => void; title: string; children: ReactNode; footer?: ReactNode }) {
  useEffect(() => {
    if (!open) return
    const onKey = (e: KeyboardEvent) => e.key === 'Escape' && onClose()
    document.addEventListener('keydown', onKey)
    const prev = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    return () => {
      document.removeEventListener('keydown', onKey)
      document.body.style.overflow = prev
    }
  }, [open, onClose])
  if (!open) return null
  return (
    <div className="fixed inset-0 z-50 flex items-end justify-center sm:items-center sm:p-6" role="dialog" aria-modal="true" aria-label={title}>
      <div className="absolute inset-0 bg-stone-900/30" onClick={onClose} />
      <div className="relative flex max-h-[92dvh] w-full flex-col rounded-t-3xl bg-paper shadow-xl sm:max-w-lg sm:rounded-3xl">
        <div className="flex items-center justify-between px-5 pt-5 pb-3 sm:px-6">
          <h2 className="text-lg font-bold">{title}</h2>
          <button onClick={onClose} className="grid size-9 place-items-center rounded-full text-stone-500 hover:bg-stone-200/60" aria-label="닫기">
            <X size={18} />
          </button>
        </div>
        <div className="overflow-y-auto px-5 pb-5 sm:px-6">{children}</div>
        {footer && <div className="border-t border-stone-200 px-5 py-4 pb-[max(1rem,env(safe-area-inset-bottom))] sm:px-6">{footer}</div>}
      </div>
    </div>
  )
}

/** 자유 입력 태그 (알레르기, 선호/비선호 음식 등) */
export function TagInput({ values, onChange, placeholder, suggestions = [] }: { values: string[]; onChange: (v: string[]) => void; placeholder: string; suggestions?: string[] }) {
  const [text, setText] = useState('')
  const add = (v: string) => {
    const t = v.trim()
    if (t && !values.includes(t)) onChange([...values, t])
    setText('')
  }
  const rest = suggestions.filter((s) => !values.includes(s))
  return (
    <div>
      <div className="flex gap-2">
        <input
          className={inputCls}
          value={text}
          placeholder={placeholder}
          onChange={(e) => setText(e.target.value)}
          onKeyDown={(e) => {
            if (e.key === 'Enter' && !e.nativeEvent.isComposing) {
              e.preventDefault()
              add(text)
            }
          }}
        />
        <Button type="button" variant="secondary" className="h-11 shrink-0" onClick={() => add(text)} disabled={!text.trim()}>
          추가
        </Button>
      </div>
      {(values.length > 0 || rest.length > 0) && (
        <div className="mt-2.5 flex flex-wrap gap-1.5">
          {values.map((v) => (
            <span key={v} className="inline-flex h-8 items-center gap-1 rounded-full bg-sage-700 pl-3 pr-1.5 text-[13px] font-medium text-white">
              {v}
              <button type="button" onClick={() => onChange(values.filter((x) => x !== v))} className="grid size-5 place-items-center rounded-full hover:bg-white/20" aria-label={`${v} 삭제`}>
                <X size={12} />
              </button>
            </span>
          ))}
          {rest.map((s) => (
            <button key={s} type="button" onClick={() => add(s)} className="inline-flex h-8 items-center gap-1 rounded-full bg-white px-3 text-[13px] text-stone-600 ring-1 ring-stone-200 hover:ring-sage-300">
              <Plus size={12} />
              {s}
            </button>
          ))}
        </div>
      )}
    </div>
  )
}

export function SectionTitle({ title, desc, action }: { title: string; desc?: string; action?: ReactNode }) {
  return (
    <div className="mb-3 flex items-end justify-between gap-3">
      <div>
        <h2 className="text-[17px] font-bold tracking-tight">{title}</h2>
        {desc && <p className="mt-0.5 text-[13px] text-stone-500">{desc}</p>}
      </div>
      {action}
    </div>
  )
}
