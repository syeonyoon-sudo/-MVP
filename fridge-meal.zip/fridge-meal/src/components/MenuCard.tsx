import { ArrowRight, Clock, ShoppingBasket, Check, AlertCircle } from 'lucide-react'
import type { MenuRec } from '../types'
import { Badge, Button, Card } from './ui'
import { DifficultyDots, ExpiryBadge, MenuVisual } from './bits'
import { navigate } from '../store'

export function MenuCard({ menu, rank }: { menu: MenuRec; rank: number }) {
  const r = menu.recipe
  return (
    <Card className="flex flex-col overflow-hidden">
      <div className="flex gap-4 p-5 pb-4">
        <MenuVisual recipe={r} />
        <div className="min-w-0 flex-1">
          <div className="flex items-center gap-1.5 text-[12px] font-semibold text-stone-500">
            <span className="text-sage-700">추천 {rank}</span>
            <span>·</span>
            <span>{r.category}</span>
            {menu.source === 'ai' && <Badge className="bg-sage-50 text-sage-700 ring-1 ring-sage-200">AI 작성</Badge>}
          </div>
          <h3 className="mt-0.5 text-[18px] leading-snug font-bold tracking-tight">{r.name}</h3>
          <div className="mt-1.5 flex flex-wrap items-center gap-x-3 gap-y-1 text-[13px] text-stone-600">
            <span className="inline-flex items-center gap-1">
              <Clock size={14} className="text-stone-400" />
              {r.time}분
            </span>
            <DifficultyDots level={r.difficulty} />
          </div>
        </div>
      </div>

      <p className="mx-5 rounded-xl bg-paper px-3.5 py-3 text-[13.5px] leading-relaxed text-stone-700">{menu.reason}</p>

      <dl className="space-y-3.5 px-5 py-4 text-[13.5px]">
        {menu.priorityUsed.length > 0 && (
          <div>
            <dt className="mb-1.5 text-[12px] font-semibold text-stone-500">우선 소비 재료</dt>
            <dd className="flex flex-wrap gap-1.5">
              {menu.priorityUsed.map((p) => (
                <span key={p.name} className="inline-flex items-center gap-1.5 rounded-lg bg-white py-1 pr-1.5 pl-2.5 font-medium ring-1 ring-stone-200">
                  {p.name}
                  <ExpiryBadge days={p.daysLeft} />
                </span>
              ))}
            </dd>
          </div>
        )}
        <div>
          <dt className="mb-1 text-[12px] font-semibold text-stone-500">사용하는 보유 재료</dt>
          <dd className="flex items-start gap-1.5 text-stone-800">
            <Check size={15} className="mt-0.5 shrink-0 text-sage-600" />
            <span>{[...menu.owned, ...menu.optionalOwned].join(', ')}</span>
          </dd>
        </div>
        <div>
          <dt className="mb-1 flex items-center gap-1.5 text-[12px] font-semibold text-stone-500">
            추가 구매 필요
            <Badge className={menu.toBuy.length ? 'bg-amber-50 text-amber-800 ring-1 ring-amber-200' : 'bg-sage-50 text-sage-700 ring-1 ring-sage-200'}>{menu.toBuy.length}개</Badge>
          </dt>
          <dd className="flex items-start gap-1.5">
            {menu.toBuy.length ? (
              <>
                <ShoppingBasket size={15} className="mt-0.5 shrink-0 text-amber-600" />
                <span className="text-stone-800">{menu.toBuy.map((t) => (t.kind === 'seasoning' ? `${t.name}(양념)` : t.name)).join(', ')}</span>
              </>
            ) : (
              <span className="text-stone-500">없음 — 지금 있는 재료로 만들 수 있어요</span>
            )}
          </dd>
        </div>
      </dl>

      <div className="mt-auto border-t border-stone-100 p-4">
        <Button className="w-full" onClick={() => navigate(`/recipe/${r.id}`)}>
          상세 조리법 보기
          <ArrowRight size={16} />
        </Button>
      </div>
    </Card>
  )
}

export function Notice({ tone = 'info', children }: { tone?: 'info' | 'warn' | 'danger'; children: React.ReactNode }) {
  const cls = { info: 'bg-sage-50 text-sage-900 ring-sage-200', warn: 'bg-amber-50 text-amber-900 ring-amber-200', danger: 'bg-red-50 text-red-900 ring-red-200' }[tone]
  return (
    <div className={`flex gap-2.5 rounded-xl px-4 py-3 text-[13.5px] leading-relaxed ring-1 ${cls}`}>
      <AlertCircle size={16} className="mt-0.5 shrink-0" />
      <div className="min-w-0">{children}</div>
    </div>
  )
}
