import { useEffect, useState } from 'react'
import { Info } from 'lucide-react'
import type { Ingredient, StorageType } from '../types'
import { Button, Field, Segmented, Sheet, inputCls, cx } from './ui'
import { QUICK_ITEMS, UNITS, STORAGE_LABEL } from '../lib/presets'
import { addDays, daysLeft, todayStr, statusOf, STATUS_META, dLabel } from '../lib/expiry'

type Draft = Omit<Ingredient, 'id' | 'createdAt'>

export function emptyDraft(): Draft {
  return { name: '', quantity: 1, unit: '개', expiry: addDays(todayStr(), 3), storage: 'fridge' }
}

export function draftFromQuick(name: string): Draft {
  const q = QUICK_ITEMS.find((x) => x.name === name)
  if (!q) return { ...emptyDraft(), name }
  return { name: q.name, quantity: q.qty, unit: q.unit, expiry: addDays(todayStr(), q.days), storage: q.storage }
}

export function IngredientForm({ open, initial, editing, onClose, onSubmit, onDelete }: { open: boolean; initial: Draft; editing?: boolean; onClose: () => void; onSubmit: (d: Draft) => void; onDelete?: () => void }) {
  const [d, setD] = useState<Draft>(initial)
  const [estimated, setEstimated] = useState(false)
  useEffect(() => {
    if (open) {
      setD(initial)
      setEstimated(!editing && QUICK_ITEMS.some((q) => q.name === initial.name))
    }
  }, [open, initial, editing])

  const set = <K extends keyof Draft>(k: K, v: Draft[K]) => setD((p) => ({ ...p, [k]: v }))
  const onName = (name: string) => {
    const q = QUICK_ITEMS.find((x) => x.name === name.trim())
    if (q && !editing) {
      setD({ name: q.name, quantity: q.qty, unit: q.unit, expiry: addDays(todayStr(), q.days), storage: q.storage })
      setEstimated(true)
    } else set('name', name)
  }
  const valid = d.name.trim().length > 0 && d.quantity > 0 && /^\d{4}-\d{2}-\d{2}$/.test(d.expiry)
  const days = valid ? daysLeft(d.expiry) : null
  const st = days !== null ? statusOf(days) : null

  return (
    <Sheet
      open={open}
      onClose={onClose}
      title={editing ? '식재료 수정' : '식재료 등록'}
      footer={
        <div className="flex gap-2">
          {editing && onDelete && (
            <Button variant="danger" onClick={onDelete}>
              삭제
            </Button>
          )}
          <Button variant="secondary" className="ml-auto" onClick={onClose}>
            취소
          </Button>
          <Button disabled={!valid} onClick={() => onSubmit({ ...d, name: d.name.trim() })}>
            {editing ? '저장' : '냉장고에 넣기'}
          </Button>
        </div>
      }
    >
      <form
        className="space-y-4"
        onSubmit={(e) => {
          e.preventDefault()
          if (valid) onSubmit({ ...d, name: d.name.trim() })
        }}
      >
        <Field label="식재료명">
          <input className={inputCls} value={d.name} onChange={(e) => onName(e.target.value)} placeholder="예: 두부, 대파, 돼지고기" list="ingredient-names" autoFocus={!editing} />
          <datalist id="ingredient-names">
            {QUICK_ITEMS.map((q) => (
              <option key={q.name} value={q.name} />
            ))}
          </datalist>
        </Field>
        <div className="grid grid-cols-2 gap-3">
          <Field label="수량">
            <input className={inputCls} type="number" inputMode="decimal" min={0} step="any" value={Number.isFinite(d.quantity) ? d.quantity : ''} onChange={(e) => set('quantity', parseFloat(e.target.value))} />
          </Field>
          <Field label="단위">
            <select className={inputCls} value={d.unit} onChange={(e) => set('unit', e.target.value)}>
              {(UNITS.includes(d.unit) ? UNITS : [d.unit, ...UNITS]).map((u) => (
                <option key={u}>{u}</option>
              ))}
            </select>
          </Field>
        </div>
        <Field label="소비기한">
          <input
            className={inputCls}
            type="date"
            value={d.expiry}
            onChange={(e) => {
              set('expiry', e.target.value)
              setEstimated(false)
            }}
          />
          <div className="mt-2 flex flex-wrap gap-1.5">
            {[
              ['오늘', 0],
              ['내일', 1],
              ['+3일', 3],
              ['+7일', 7],
              ['+14일', 14],
              ['+1개월', 30],
            ].map(([l, n]) => (
              <button
                key={l}
                type="button"
                onClick={() => {
                  set('expiry', addDays(todayStr(), n as number))
                  setEstimated(false)
                }}
                className="h-7 rounded-md bg-stone-100 px-2.5 text-xs font-medium text-stone-600 hover:bg-sage-100 hover:text-sage-800"
              >
                {l}
              </button>
            ))}
          </div>
          {st && days !== null && (
            <div className="mt-2 flex items-center gap-2 text-[13px]">
              <span className={cx('rounded-md px-1.5 py-0.5 text-[11.5px] font-semibold', STATUS_META[st].badge)}>{dLabel(days)}</span>
              <span className="text-stone-500">{STATUS_META[st].label}</span>
            </div>
          )}
          {estimated && (
            <p className="mt-2 flex items-start gap-1.5 rounded-lg bg-amber-50 px-2.5 py-2 text-xs leading-relaxed text-amber-900">
              <Info size={14} className="mt-px shrink-0" />
              일반적인 보관 기간으로 미리 채웠어요. 포장지에 적힌 소비기한으로 바꿔 주세요.
            </p>
          )}
        </Field>
        <Field label="보관 방식">
          <Segmented<StorageType>
            value={d.storage}
            onChange={(v) => set('storage', v)}
            options={(['fridge', 'freezer', 'room'] as StorageType[]).map((s) => ({ value: s, label: STORAGE_LABEL[s] }))}
          />
        </Field>
        <button type="submit" className="hidden" />
      </form>
    </Sheet>
  )
}
