// GET /api/status — 서버에 AI API 키가 설정되어 있는지만 알려줍니다. (키 값은 절대 반환하지 않음)
export default function handler(_req: any, res: any) {
  const available = !!process.env.ANTHROPIC_API_KEY
  res.setHeader('Cache-Control', 'no-store')
  res.status(200).json({
    aiAvailable: available,
    model: available ? process.env.ANTHROPIC_MODEL || 'claude-sonnet-5-5' : null,
  })
}
