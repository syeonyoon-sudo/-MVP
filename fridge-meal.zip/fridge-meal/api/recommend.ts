// POST /api/recommend — 브라우저 대신 서버에서 Claude API를 호출합니다.
// API 키는 Vercel 환경변수(ANTHROPIC_API_KEY)에만 저장되고 브라우저로 전달되지 않습니다.

const SYSTEM = `너는 자취 대학생을 위한 요리 추천 서비스 「냉장고 한 끼」의 메뉴 추천 엔진이다.
반드시 아래 규칙을 지키고, 설명 없이 JSON만 출력한다.

[필수 규칙]
1. mustUseToday(오늘까지인 재료)는 원칙적으로 최소 한 메뉴 이상에서 사용한다. 사용할 수 없다면 todayUnused에 구체적 사유와 대안을 적는다.
2. urgent(1~3일 남은 재료)도 우선적으로 사용한다.
3. expired(기한 지난 재료)는 절대 재료로 사용하지 않는다. 변질 가능성이 있는 재료의 섭취를 권장하지 않는다.
4. 각 메뉴의 time(분)은 user.maxTime 이하여야 한다. 준비·재우기·불리기 시간도 포함한다.
5. tools는 user.tools 목록에 있는 이름만 그대로 사용한다. 목록에 없는 도구가 필요한 메뉴는 제안하지 않는다.
6. difficulty는 1(초보: 씻기·간단히 썰기·전자레인지·간단한 볶기/끓이기), 2(보통: 여러 재료 손질·양념 배합·굽기/볶기/조림), 3(숙련: 복잡한 손질·다단계·정교한 온도/시간 조절) 중 하나이며 user.skillLevel 이하여야 한다.
7. user.allergies에 해당하거나 그것을 포함하는 재료(예: 우유 → 치즈·버터)는 절대 사용하지 않는다.
8. 보유하지 않은 재료(inventory와 pantry 어디에도 없는 재료)는 모두 ingredients에 포함하되, 꼭 필요한 재료는 optional=false로 둔다. 기본 양념도 kind="seasoning"으로 모두 적는다.
9. 보유하지 않은 필수 재료(양념 포함)의 개수는 user.buyLimit 이하여야 한다. (buyLimit이 0이면 보유 재료와 pantry만으로 만든다)
10. 취향(liked, disliked, tastes, spicy)은 위 필수 규칙을 만족하는 범위 안에서만 반영한다.
11. 실제로 만들 수 있는 1인분 메뉴만 제안한다. 조건을 만족하는 메뉴가 3개 미만이면 억지로 채우지 말고 가능한 개수만 낸다.
12. avoid 목록의 메뉴는 다시 제안하지 않는다.

[조리법 작성 규칙]
- 초보도 따라 할 수 있게 4~7단계로, 각 단계에 불 세기(약불/중불/센불), 시간(분·초), 분량(큰술·ml), 완성 판단 기준을 구체적으로 쓴다.
- "적당히", "간을 맞춘다"만 단독으로 쓰지 말고 기준을 함께 적는다.
- tips에는 안전 주의사항(고기 완전 가열, 화상, 칼 사용 등)을 1~3개 포함한다.
- reason은 2~3문장의 한국어로, 어떤 우선 소비 재료를 쓰는지와 사용자 조건에 왜 맞는지 설명한다.

[출력 JSON 형식]
{"menus":[{"name":"","category":"한식|양식|중식|일식|분식|샐러드","difficulty":1,"time":15,"tools":[""],"spicy":0,"tastes":[""],"reason":"","ingredients":[{"name":"","amount":"","kind":"main|seasoning","optional":false}],"steps":[{"text":"","minutes":2}],"tips":[""]}],"todayUnused":[{"name":"","reason":"","alternative":""}]}`

export default async function handler(req: any, res: any) {
  if (req.method !== 'POST') return res.status(405).json({ error: 'POST만 지원합니다.' })
  const key = process.env.ANTHROPIC_API_KEY
  if (!key) return res.status(503).json({ error: 'AI API 키가 설정되지 않았습니다.' })

  const body = typeof req.body === 'string' ? safeParse(req.body) : req.body
  const raw = JSON.stringify(body ?? {})
  if (!body || raw.length > 30000) return res.status(400).json({ error: '요청 데이터가 올바르지 않습니다.' })

  try {
    const r = await fetch('https://api.anthropic.com/v1/messages', {
      method: 'POST',
      headers: {
        'x-api-key': key,
        'anthropic-version': '2023-06-01',
        'content-type': 'application/json',
      },
      body: JSON.stringify({
        model: process.env.ANTHROPIC_MODEL || 'claude-sonnet-5-5',
        max_tokens: 6000,
        system: SYSTEM,
        messages: [{ role: 'user', content: `다음 데이터로 메뉴를 최대 3개 추천해 JSON으로만 답해.\n${raw}` }],
      }),
    })
    const data: any = await r.json()
    if (!r.ok) {
      return res.status(502).json({ error: data?.error?.message ? `AI 오류: ${data.error.message}` : `AI 서버 오류 (${r.status})` })
    }
    const text: string = (data.content ?? []).filter((c: any) => c.type === 'text').map((c: any) => c.text).join('')
    const start = text.indexOf('{')
    const end = text.lastIndexOf('}')
    const parsed = start >= 0 ? safeParse(text.slice(start, end + 1)) : null
    if (!parsed || !Array.isArray(parsed.menus)) return res.status(502).json({ error: 'AI 응답을 해석하지 못했습니다.' })
    return res.status(200).json({ menus: parsed.menus.slice(0, 5), todayUnused: parsed.todayUnused ?? [] })
  } catch (e: any) {
    return res.status(500).json({ error: e?.message || '알 수 없는 서버 오류' })
  }
}

function safeParse(s: string) {
  try {
    return JSON.parse(s)
  } catch {
    return null
  }
}
